import { Button } from "react-bootstrap";
import { PieChart, Table } from "../components/ui-elements";
import {
  PageHeader,
  PageLayoutWithAuthGuard,
} from "../components/ui-universal";
import { authFn } from "../functions/account/auth";
import { BarChart } from "../components/ui-elements/chart/BarChart";
import { mockDonutChart, mockExpenseBarChart } from "../mocks/chart";

const DashboardPage = () => {
  const logoutTest = () => {
    authFn.logout();
  };

  return (
    <PageLayoutWithAuthGuard>
      <PageHeader title={"Dashboard"} />
      <div>Dashboard test</div>
      <Button variant="primary" onClick={logoutTest}>
        Log out
      </Button>
      <Table
        id="test-id"
        items={[
          { testid: 1, content: "Test content 1" },
          { testid: 2, content: "Test content 2" },
        ]}
      ></Table>
      <div className="d-block" style={{ width: "500px" }}>
        <BarChart
          options={mockExpenseBarChart.options}
          data={mockExpenseBarChart.data}
        />
      </div>
      <div className="d-block" style={{ width: "500px" }}>
        <PieChart
          options={mockDonutChart.options}
          data={mockDonutChart.data}
          subType="donut"
        />
      </div>
    </PageLayoutWithAuthGuard>
  );
};

export default DashboardPage;

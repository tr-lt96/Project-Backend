import { ForgotPasswordCard } from "../../components/pages";
import { PageLayoutBase } from "../../components/ui-universal/page-layout/PageLayoutBase";

export const ForgotPasswordPage = () => {
  return (
    <PageLayoutBase>
      <div className="row">
        <div className="col-lg-4 mx-auto">
          <ForgotPasswordCard />
        </div>
      </div>
    </PageLayoutBase>
  );
};

//&oobCode=fPTbV-gUvkjD-SYMdVDzKZC39Hn6DKavuQLoLCP2Mkw

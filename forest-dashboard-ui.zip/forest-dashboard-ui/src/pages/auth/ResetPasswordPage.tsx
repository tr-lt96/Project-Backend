import { ResetPasswordCard } from "../../components/pages/auth/ResetPasswordCard";
import { PageLayoutBase } from "../../components/ui-universal";

export const ResetPasswordPage = () => {
  return (
    <PageLayoutBase>
      <div className="row">
        <div className="col-lg-4 mx-auto">
          <ResetPasswordCard />
        </div>
      </div>
    </PageLayoutBase>
  );
};

import { useNavigate, useSearchParams } from "react-router-dom";
import { RoutePathname } from "../../utils/router";
import { PageLayoutBase } from "../../components/ui-universal";
import { useEffect } from "react";
import { useAuthGuard } from "../../hooks/account";
import { SignUpCard, SignInCard } from "../../components/pages";
import {
  AuthPageProvider,
  useAuthPageContext,
} from "../../components/contexts/page";

// /auth?register=true
const DisplayAuthFormCard = () => {
  const { authState } = useAuthPageContext();

  return authState === "signup" ? <SignUpCard /> : <SignInCard />;
};
export const AuthPage = () => {
  const [params] = useSearchParams();
  const { isValidating, isAuthorised } = useAuthGuard({ autoRedirect: false });
  const navigate = useNavigate();

  const initAuthState = params.get("register") === "true" ? "signup" : "signin";

  useEffect(() => {
    if (!isValidating && isAuthorised !== null) {
      if (isAuthorised) {
        navigate(RoutePathname.dashboard);
      }
    }
  }, [isValidating, isAuthorised]);

  return (
    <PageLayoutBase>
      <div className="row">
        <div className="col-lg-4 mx-auto">
          <AuthPageProvider initAuthState={initAuthState}>
            <DisplayAuthFormCard />
          </AuthPageProvider>
        </div>
      </div>
    </PageLayoutBase>
  );
};

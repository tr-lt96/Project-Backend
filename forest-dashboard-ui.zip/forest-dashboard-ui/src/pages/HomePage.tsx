import { useNavigate } from "react-router-dom";
import { useAuthGuard } from "../hooks/account";
import { RoutePathname } from "../utils/router";
import { useEffect } from "react";
import { PageLoading } from "../components/ui-universal/page-loading/PageLoading";

const HomePage = () => {
  const { isValidating, isAuthorised } = useAuthGuard();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isValidating && isAuthorised !== null) {
      if (isAuthorised) {
        navigate(RoutePathname.dashboard);
      } else {
        navigate(RoutePathname.auth);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isValidating, isAuthorised]);

  return <PageLoading message="Redirecting..." />;
};

export default HomePage;

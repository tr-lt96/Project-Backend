import { useNavigate } from "react-router-dom";
import { useAuthContext } from "../../components/contexts/account";
import { RoutePathname } from "../../utils/router";
import { useEffect, useState } from "react";

interface IAuthGuardOption {
  autoRedirect?: boolean;
}
export const useAuthGuard = (option?: IAuthGuardOption) => {
  const { autoRedirect = true } = option || {};
  const { user, isValidatingUser } = useAuthContext();
  const [isAuthorised, setIsAuthorised] = useState<boolean | null>(null);

  const navigate = useNavigate();

  const navigateToAuthPage = () => {
    if (autoRedirect) {
      navigate(RoutePathname.auth);
    }
  };

  useEffect(() => {
    if (!isValidatingUser) {
      if (!user) {
        navigateToAuthPage();
        setIsAuthorised(false);
      } else {
        setIsAuthorised(true);
      }
    }
  }, [isValidatingUser]);

  return {
    isValidating: isValidatingUser,
    isAuthorised,
  };
};

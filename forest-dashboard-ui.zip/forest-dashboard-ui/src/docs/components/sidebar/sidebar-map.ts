import { SidebarMenuGroup } from "../../../components/ui-universal/sidebar/sidebar-map";

export const DocsSidebarMenuGroups: SidebarMenuGroup[] = [
  {
    groupLabel: "Documentation",
    items: [
      {
        label: "App structure",
        iconName: "IconoirReportColumns",
        subItems: [
          { label: "Folder and files", href: "/docs/folder-and-files" },
          { label: "Application setup", href: "/docs/application-setup" },
          { label: "Routing", href: "/docs/routing" },
          { label: "Contexts", href: "/docs/contexts" },
          { label: "Additional resources", href: "/docs/additional-resources" },
        ],
      },
      {
        label: "UI basic elements",
        iconName: "IconoirPalette",
        subItems: [
          { label: "Alert", href: "/docs/alert" },
          { label: "Badge", href: "/docs/badge" },
          { label: "Button & IconButton", href: "/docs/button" },
          { label: "Card", href: "/docs/card" },
          { label: "Icon", href: "/docs/icon" },
          { label: "Pagination", href: "/docs/pagination" },
          { label: "Table", href: "/docs/table" },
        ],
      },
      {
        label: "UI app elements",
        iconName: "IconoirCreditCards",
        subItems: [
          { label: "TopNavbar", href: "/docs/topnavbar" },
          { label: "Sidebar", href: "/docs/sidebar" },
          { label: "Page layout", href: "/docs/page-layout" },
          { label: "Page header", href: "/docs/page-header" },
          { label: "Page error", href: "/docs/page-error" },
          { label: "Page loading", href: "/docs/page-loading" },
        ],
      },
      {
        label: "Form",
        iconName: "IconoirPasteClipboard",
        subItems: [
          { label: "Basic elements", href: "/docs/basic-elements" },
          { label: "Validation", href: "/docs/validation" },
          { label: "Submit form", href: "/docs/submit-form" },
        ],
      },
      {
        label: "Authentication Flow",
        iconName: "IconoirGroup",
        subItems: [
          { label: "Auth page", href: "/docs/auth-page" },
          { label: "Auth forms", href: "/docs/auth-forms" },
          { label: "Forgot password", href: "/docs/forgot-password" },
          { label: "Reset password", href: "/docs/reset-password" },
        ],
      },
      { label: "Chart", iconName: "IconoirReportsSolid" },
    ],
  },
];

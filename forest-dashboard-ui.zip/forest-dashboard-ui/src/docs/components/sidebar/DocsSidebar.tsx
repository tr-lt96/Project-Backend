import SimpleBar from "simplebar-react";
import "simplebar-react/dist/simplebar.min.css";
import { DocsSidebarMenuGroups } from "./sidebar-map";
import { SidebarGroup } from "../../../components/ui-universal/sidebar/SidebarGroup";
import { useNavbarContext } from "../../../components/contexts/app";

export const DocsSidebar = () => {
  const { closeSidebar } = useNavbarContext();

  const SidebarGroups = () => {
    return DocsSidebarMenuGroups.map((group, index) => {
      const key = `sidebar-doc-group-${group.groupLabel}-${index}`;
      return <SidebarGroup key={key} {...group} />;
    });
  };

  return (
    <>
      <div className="startbar d-print-none">
        <div className="brand"></div>
        <div className="startbar-menu">
          <SimpleBar className="startbar-collapse">
            <div className="d-flex align-items-start flex-column w-100">
              <SidebarGroups />
            </div>
          </SimpleBar>
        </div>
      </div>
      {/* Overlay layer for side bar */}
      <div className="startbar-overlay d-print-none" onClick={closeSidebar} />
    </>
  );
};

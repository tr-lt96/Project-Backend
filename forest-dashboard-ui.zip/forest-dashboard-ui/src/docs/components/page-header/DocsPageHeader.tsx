import { useLocation } from "react-router-dom";
import { Breadcrumb, BreadcrumbItem } from "react-bootstrap";
import { useMemo } from "react";
import { DocsValidPathSegments } from "./docs-route-map";

export const DocsPageHeader = ({ title }: { title: string }) => {
  const { pathname } = useLocation();
  const breadCrumbs = useMemo(
    () =>
      pathname
        .split("/")
        .filter((pn) => DocsValidPathSegments.includes(pn))
        .map((pn) => pn[0].toUpperCase() + pn.substring(1).toLowerCase())
        .map((pn) => pn.split("-").join(" ")),
    []
  );

  const BreadCrumbItems = () => {
    return breadCrumbs.map((breadCrumb, index) => {
      const key = `breadcrumb-${breadCrumb}-${index}`;
      return <BreadcrumbItem key={key}>{breadCrumb}</BreadcrumbItem>;
    });
  };

  return (
    <div className="row">
      <div className="col-sm-12">
        <div className="page-title-box d-md-flex justify-content-md-between align-items-center">
          <h4 className="page-title">{title}</h4>
          <Breadcrumb as="div">
            <BreadCrumbItems />
          </Breadcrumb>
        </div>
      </div>
    </div>
  );
};

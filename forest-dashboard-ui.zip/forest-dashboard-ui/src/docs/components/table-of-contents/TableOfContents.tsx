interface ITOCItem {
  label: string;
  labelId: string;
  subItems?: ITOCItem[];
}

export const TOCItem = ({ label, labelId }: ITOCItem) => {
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    document?.querySelector(`#${labelId}`)?.scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  };

  return (
    <a href={`#${labelId}`} onClick={handleClick}>
      {label}
    </a>
  );
};

export const TOCNestedItem = ({ subItems, ...item }: ITOCItem) => {
  const getRenderQueue = () => {};
};

export const TableOfContents = () => {
  return;
};

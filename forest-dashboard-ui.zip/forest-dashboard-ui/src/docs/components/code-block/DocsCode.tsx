import { CodeBlock, dracula } from "react-code-blocks";

export const DocsCode = ({
  text,
  language,
}: {
  text: string;
  language: string;
}) => {
  return (
    <div style={{ fontFamily: "monospace" }}>
      <CodeBlock
        text={text}
        language={language}
        theme={dracula}
        showLineNumbers
        codeBlockStyle={{ fontFamily: "monospace" }}
      />
    </div>
  );
};

import { useNavbarContext } from "../../../components/contexts/app";
import { IconButton } from "../../../components/ui-elements";
import { ThemeToggle } from "../../../components/ui-universal/navbar/ThemeToggle";

export const DocsTopNavbar = () => {
  const { toggleSidebar } = useNavbarContext();

  return (
    <div className="topbar d-print-none">
      <div className="container-fluid">
        <nav className="topbar-custom d-flex justify-content-between">
          {/* left-hand side of top bar */}
          <ul className="topbar-item list-unstyled d-inline-flex align-items-center mb-0">
            <li>
              <IconButton
                iconName={"IconoirMenu"}
                onClick={toggleSidebar}
                variant={"transparent"}
                color={"light"}
              />
            </li>
          </ul>

          {/* right-hand side of top bar */}
          <ul className="topbar-item list-unstyled d-inline-flex align-items-center mb-0">
            <li>
              <ThemeToggle />
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
};

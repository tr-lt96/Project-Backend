import { DocsTopNavbar } from "./navbar/DocsTopNavbar";
import { DocsPageHeader } from "./page-header/DocsPageHeader";
import { DocsSidebar } from "./sidebar/DocsSidebar";

export const DocsPageLayout = ({
  children,
  title,
}: {
  children: React.ReactNode;
  title: string;
}) => {
  return (
    <>
      {/* This is the top navigation bar (i.e. header) */}
      <DocsTopNavbar />
      {/* This is the side navigation bar (i.e. menu sidebar) */}
      <DocsSidebar />
      {/* This is the rest of page*/}
      <div className="page-wrapper fw-normal fs-16">
        <div className="page-content">
          <div className="container-fluid">
            <div className="row d-flex justify-content-center">
              <div className="col-8" style={{ maxWidth: "900px" }}>
                <DocsPageHeader title={title} />
                {children}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

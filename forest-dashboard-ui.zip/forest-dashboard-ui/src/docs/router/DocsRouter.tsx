import { Route, Routes } from "react-router-dom";
import { DocStartPage } from "../pages/DocStartPage";
import { DocsRoutePathname } from "../components/page-header/docs-route-map";
import { FolderAndFilesPage } from "../pages/app-structure/FolderAndFilesPage";
import { ApplicationSetupPage } from "../pages/app-structure/ApplicationSetupPage";
import { AlertPage } from "../pages/ui-basic-elements/AlertPage";
import { BadgePage } from "../pages/ui-basic-elements/BadgePage";
import { ButtonPage } from "../pages/ui-basic-elements/ButtonPage";
import { RoutingPage } from "../pages/app-structure/RoutingPage";
import { ResourcePage } from "../pages/app-structure/AdditionalResources";

export const DocsRouter = () => {
  return (
    <Routes>
      <Route path={"/"} element={<DocStartPage />} />
      <Route
        path={DocsRoutePathname.folderAndFiles}
        element={<FolderAndFilesPage />}
      />
      <Route
        path={DocsRoutePathname.applicationSetup}
        element={<ApplicationSetupPage />}
      />
      <Route
        path={DocsRoutePathname.additionalResources}
        element={<ResourcePage />}
      />
      <Route path={DocsRoutePathname.routing} element={<RoutingPage />} />
      <Route path={DocsRoutePathname.alert} element={<AlertPage />} />
      <Route path={DocsRoutePathname.badge} element={<BadgePage />} />
      <Route path={DocsRoutePathname.button} element={<ButtonPage />} />
    </Routes>
  );
};

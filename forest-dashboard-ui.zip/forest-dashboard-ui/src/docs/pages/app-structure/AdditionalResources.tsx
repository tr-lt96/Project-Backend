import { DocsPageLayout } from "../../components/DocsPageLayout";
import { Link } from "react-router-dom";

const Page = () => {
  return (
    <DocsPageLayout title="Resources">
      <div className="col-12">
        <h3 className="mt-4">Basic web framework documentations</h3>
        <div className="pb-2 border-bottom">
          <ul className="py-2">
            <li>
              <Link to="https://react.dev/learn">
                Learn basic React concepts
              </Link>
            </li>

            <ul className="pt-2">
              <li>
                <Link to="https://react.dev/reference/react/hooks">
                  React Hook Basics
                </Link>
              </li>
              <li className="pt-2">
                <Link to="https://react.dev/learn/state-a-components-memory">
                  Component States
                </Link>
              </li>
              <li className="pt-2">
                <Link to="https://react.dev/learn/passing-data-deeply-with-context">
                  Context and Context Provider
                </Link>
              </li>
            </ul>

            <li className="pt-2">
              <Link to="https://vite.dev/guide/">Vite in a nutshell</Link>
            </li>

            <li className="pt-2">
              <Link to="https://reactrouter.com/start/library/routing">
                react-router-dom library
              </Link>
            </li>
          </ul>
        </div>

        <h3 className="mt-4">Add-on libraries</h3>
        <div className="pb-2">
          <ul className="py-2">
            <li>
              Bootstrap (styling framework)
              <ul className="pt-2">
                <li>
                  <Link to="https://react-bootstrap.netlify.app/docs/components/accordion">
                    React bootstrap components
                  </Link>
                </li>
                <li className="pt-2">
                  <Link to="https://getbootstrap.com/docs/4.0/getting-started/introduction/">
                    Bootstrap 4
                  </Link>
                </li>
              </ul>
            </li>
            <li className="pt-2">
              Chart
              <ul className="pt-2">
                <li>
                  <Link to="">Basic Chart</Link>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const ResourcePage = Page;

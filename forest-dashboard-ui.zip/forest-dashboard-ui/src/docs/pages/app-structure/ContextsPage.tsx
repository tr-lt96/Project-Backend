import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";

const Page = () => {
  return (
    <DocsPageLayout title="Contexts">
      <div className="col-12">
        <div className="pb-2">
          <Card>
            <Card.Body>
              <p className="my-2 lh-base">TBA</p>
            </Card.Body>
          </Card>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const ContextPage = Page;

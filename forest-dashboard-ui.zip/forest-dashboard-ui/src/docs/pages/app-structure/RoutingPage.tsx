import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";
import { Link } from "react-router-dom";
import { DocsRoutePathname } from "../../components/page-header/docs-route-map";
import { DocsCode } from "../../components/code-block/DocsCode";

const appTsx = `// ./src/App.tsx

import "./assets/css/bootstrap.css";
import "./assets/css/app.css";
import "./assets/css/icons.css";
import { AppProvider } from "./components/contexts/app";
import { AppRouter } from "./utils/router";

function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}

export default App;
`;

const AppRouterTsx = `// src/utils/router/AppRouter.tsx

import {
  createBrowserRouter,
  Route,
  RouterProvider,
  Routes,
} from "react-router-dom";
import DashboardPage from "../../pages/DashboardPage";
import HomePage from "../../pages/HomePage";
import { AuthPage } from "../../pages/auth/AuthPage";
import { PageError } from "../../components/ui-universal";

const RootElement = () => {

  return (
    <main
      id="app-content"
    >
      <Routes>

        {/** Edit the below section to add or remove page*/}
        {/** ---- BEGIN ------*/}

        <Route path="/" element={<HomePage />} />
        <Route path={"/dashboard"} element={<DashboardPage />} />
        <Route path={"/auth"} element={<AuthPage />} />
        <Route
          path="*"
          element={<PageError code={404} message={'404 not found'} />}
        />

        {/** ---- END ------*/}

      </Routes>
    </main>
  );
};

const router = createBrowserRouter([{ path: "*", element: <RootElement /> }]);

export const AppRouter = () => {
  return <RouterProvider router={router}></RouterProvider>;
};

`;

const Page = () => {
  return (
    <DocsPageLayout title="App router">
      <div className="col-12">
        <div className="pb-2">
          <Card>
            <Card.Body>
              <p className="my-2 lh-base">
                This section aims to provide a quick understanding about the
                "app router" (or "page router").
              </p>
            </Card.Body>
          </Card>
        </div>

        <h3 className="mt-4">
          What is <span className="fst-italic">App router</span> exactly ?
        </h3>
        <div className="pb-2 border-bottom">
          <p className="py-2">
            <span className="fst-italic">App router</span>, or "page router" is
            a method of managing navigation between different pages within a web
            application built with Vite/React, typically achieved by using a
            dedicated client-side routing library like React Router, where each
            "page" is essentially a React component that corresponds to a
            specific URL path, allowing users to navigate between different
            sections of the site without full page reloads.
          </p>
        </div>

        <h3 className="mt-4">
          Setup <code>router</code> in our application
        </h3>
        <div className="pb-2 border-botto">
          <p className="py-2">
            Currently, we utilise the package/library{" "}
            <code>react-router-dom</code> to setup our application router. To
            install the library, the command below has been run:
          </p>

          <DocsCode
            text={`npm install react-router-dom`}
            language={"bash"}
          ></DocsCode>

          <p className="mt-3 py-2">
            After the library has been installed as a dependency to our
            application, we created a file called <code>AppRouter.tsx</code>{" "}
            (the file path should be <code>src/utils/router/AppRouter.tsx</code>
            ) to contain the code necessary to create the router.
          </p>
          <DocsCode text={AppRouterTsx} language="typescript" />

          <h4 className="mt-4">
            {">>"} <code>RootElement</code> Component
          </h4>
          <div className="pb-2">
            <p className="py-2">
              The <code>RootElement</code> component defines the core route
              structure of the application. It utilizes the <code>Routes</code>{" "}
              component from <code>react-router-dom</code> to declare multiple{" "}
              <code>Route</code> entries. In the example code above:
            </p>
            <ul>
              <li>
                <code>/</code> renders the <code>HomePage</code> component.
              </li>
              <li className="pt-2">
                <code>/dashboard</code> renders the <code>DashboardPage</code>{" "}
                component.
              </li>
              <li className="pt-2">
                <code>/auth</code> renders the <code>AuthPage</code> component.
              </li>
              <li className="pt-2">
                <code>*</code> (wildcard) renders the <code>PageError</code>{" "}
                component with a 404 error message for all other routes.
              </li>
            </ul>
            <p className="pt-2">
              This structure ensures that navigation between different pages is
              managed effectively within the React application.
            </p>

            <p className="pt-2 fst-italic">
              To add a new page, (e.g. <code>/transaction</code>), simply add a
              new <code>Route</code> to <code>RootElement</code> component
            </p>

            <DocsCode
              text={`<Route path={"/example"} element={<ExamplePage />} />`}
              language="typescript"
            />

            <p className="mt-3 pt-2">
              where <code>{"<ExamplePage />"}</code> is a React component.
            </p>
          </div>

          <h4 className="mt-3">{">>"} Creating the Router Instance</h4>
          <div className="pb-2">
            <p className="py-2">
              The <code>createBrowserRouter</code> function is used to define a
              router instance, which wraps the <code>RootElement</code>{" "}
              component inside a catch-all wildcard route (<code>*</code>).
            </p>
            <DocsCode
              text={`const router = createBrowserRouter([{ path: "*", element: <RootElement /> }]);`}
              language="typescript"
            />
          </div>

          <h4 className="mt-4">
            {">>"} Using <code>RouterProvider</code>
          </h4>
          <div className="pb-2">
            <p className="py-2">
              The <code>AppRouter</code> component utilizes the{" "}
              <code>RouterProvider</code> to integrate the defined router into
              the React application, making navigation functional.
            </p>
            <DocsCode
              text={`export const AppRouter = () => { return <RouterProvider router={router} />; };`}
              language="typescript"
            />
          </div>
        </div>

        <h3 className="mt-4">
          How <code>router</code> is integrated
        </h3>
        <div className="pb-2">
          <p className="py-2">
            From{" "}
            <Link
              className="d-inline"
              to={`/docs/${DocsRoutePathname.applicationSetup}`}
            >
              Application Setup page
            </Link>
            :
          </p>

          <div className="py-2">
            <DocsCode text={appTsx} language={"typescript"} />
          </div>

          <p className="blockquote py-2">
            <code>{`<AppRouter>`}</code> is imported to the{" "}
            <code>{`App.tsx`}</code> file and used as a child component of the
            main <code>App</code> component.
          </p>

          <Link to="https://reactrouter.com/start/library/routing">
            Learn more about react-router-dom library
          </Link>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const RoutingPage = Page;

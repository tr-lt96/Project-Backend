import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";
import { DocsCode } from "../../components/code-block/DocsCode";
import { Link } from "react-router-dom";
import { DocsRoutePathname } from "../../components/page-header/docs-route-map";

const indexHtml = `<!-- ./index.html -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Forest Dashboard UI</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`;

const srcMainTsx = `// ./src/main.tsx

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
`;

const appTsx = `// ./src/App.tsx

import "./assets/css/bootstrap.css";
import "./assets/css/app.css";
import "./assets/css/icons.css";
import { AppProvider } from "./components/contexts/app";
import { AppRouter } from "./utils/router";

function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}

export default App;
`;

const firebaseTs = `// ./src/firebase.ts

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// https://firebase.google.com/docs/web/setup#available-libraries

// Firebase configuration
const firebaseConfig = {
  ...
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const appAuth = getAuth(app);
export default app;
`;

const Page = () => {
  return (
    <DocsPageLayout title="Application Setup">
      <div className="col-12">
        <div className="pb-2">
          <Card className="mb-3">
            <Card.Body>
              <p className="my-2 lh-base">
                This section aims to provide a quick understanding about Vite
                and React web application, and the application itself
              </p>
            </Card.Body>
          </Card>
        </div>

        <h3 className="mt-4">
          <strong>Vite</strong> and <strong>React</strong> in a nutshell
        </h3>
        <div className="pb-2 border-bottom">
          <h4 className="pt-3">
            <span className="fst-italic">Vite</span>, but what is it
          </h4>

          <div className="pb-2">
            <p className="pt-2">
              Vite is a <mark>front-end build tool</mark> that uses native ES
              modules and modern browser APIs to compile your code on the fly,
              providing fast build times and instant updates in the browser.
              This approach eliminates the need for a bundler during
              development, which can significantly reduce the time spent on
              building and deploying your applications. The built-in development
              server in Vite is optimized for fast reloading and hot module
              replacement, allowing developers to see the changes they make to
              their code in real-time without the need for a full page refresh.
            </p>

            <a
              href="https://vite.dev/guide/"
              target="_blank"
              className="pb-2 d-block"
            >
              https://vite.dev/guide/
            </a>
          </div>

          <h4 className="pt-3">
            Why do we use <span className="fst-italic">React</span>
          </h4>

          <div className="pb-2">
            <p className="pt-2">
              React is a popular <mark>JavaScript library</mark> for building
              user interfaces. Developed and maintained by Meta (formerly
              Facebook), React allows developers to{" "}
              <mark>build reusable UI components</mark> and manage application
              state effectively. Key features of React include:
            </p>
            <ul>
              <li>
                <strong className="text-pink">
                  Component-Based Architecture
                </strong>
                : Applications are built as a collection of reusable components.
              </li>
              <li className="pt-2">
                <strong className="text-pink">Virtual DOM</strong>: React uses a
                virtual DOM to improve performance by minimizing direct DOM
                manipulations.
              </li>
              <li className="pt-2">
                <strong className="text-pink">Declarative Syntax</strong>: React
                enables developers to describe what the UI should look like, and
                React handles the rendering.
              </li>
            </ul>

            <a
              href="https://react.dev/learn"
              target="_blank"
              className="pb-2 d-block"
            >
              https://react.dev/learn
            </a>
          </div>
        </div>

        <h3 className="mt-4">
          The <span className="fst-italic">entry</span> points of a labyrinth: a
          quick guide
        </h3>
        <div className="pb-2 border-bottom">
          <h4 className="pt-3">
            The <span className="fst-italic">entry</span> point of our web
          </h4>

          <div className="pb-2">
            <p className="pt-2">
              The entry point of a web page is the <code>index.html</code> file
              at the root of the web application repository.
            </p>

            <div className="py-2">
              <DocsCode text={indexHtml} language={"html"} />
            </div>

            <p className="py-2">
              Notice the <code>{`<div id="root"></div>`}</code> element? That's
              the container for our whole web application once mounted (i.e.
              rendered).{" "}
              <mark>
                Vite compiles our codebase into a JavaScript file that the
                browser can execute. Once the browser loads and runs this
                JavaScript file, it generates the HTML content and injects it
                into the <code>{`<div id="root"></div>`}</code> element.
              </mark>
            </p>
          </div>

          <h4 className="pt-3">
            The <span className="fst-italic">entry</span> point of our{" "}
            <span className="fst-italic">application</span>
          </h4>

          <div className="pb-2">
            <p className="pt-2">
              The highlight section above will make more sense once we break
              down what the line below does:{" "}
            </p>

            <div className="py-2" style={{ fontFamily: "monospace" }}>
              <DocsCode
                language="html"
                text={`<script type="module" src="/src/main.tsx"></script>`}
              />
            </div>

            <p className="pt-2">
              This line tells the browser to load <code>/src/main.tsx</code>{" "}
              typescript module, which is a file name <code>main.tsx</code> in
              the <code>src</code> folder.
            </p>

            <p className="pt-2">The content of this file is as below:</p>

            <div className="py-2" style={{ fontFamily: "monospace" }}>
              <DocsCode text={srcMainTsx} language={"typescript"} />
            </div>

            <p className="pt-2">Let's break down the code line by line.</p>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`import { StrictMode } from "react";`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: Imports <code>StrictMode</code>, a
                helper component from React that wraps the application.
              </li>
              <li className="pt-2">
                <strong>What it does</strong>: Highlights potential issues in
                the application. Provides additional checks and warnings in the
                development environment (e.g., deprecated APIs, unexpected side
                effects). Has no impact in the production build.
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`import { createRoot } from "react-dom/client";`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: Imports <code>createRoot</code>, the
                React 18 method for rendering the application.
              </li>
              <li className="pt-2">
                <strong>What it does</strong>: Creates a root React rendering
                container for the app. Ensures compatibility with React's new
                features, such as concurrent rendering.
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`import App from "./App.tsx";`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: Imports the main application component
                (App) from the <code>App.tsx</code> file.
              </li>
              <li className="pt-2">
                <strong>What it does</strong>: Represents the root component
                where the app's UI and logic are defined. All other components
                are typically nested inside <code>App</code> component.
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`createRoot(document.getElementById("root")!)`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>:{" "}
                <mark>Initializes the React application</mark> by creating a
                React rendering root.
              </li>
              <li className="pt-2">
                <strong>What it does</strong>:
                <ul>
                  <li className="pt-2">
                    <code>{`document.getElementById("root")`}</code>: Selects
                    the <code>{`<div id="root"></div>`}</code> element in the
                    HTML where the React app will be mounted.
                  </li>
                  <li className="pt-2">
                    The <code>{`!`}</code> (non-null assertion operator in
                    TypeScript): Ensures TypeScript that the returned element is
                    not null.
                  </li>
                  <li className="pt-2">
                    <code>{`createRoot(...)`}</code>: Creates the root container
                    for rendering React components.
                  </li>
                </ul>
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"} <code className="ms-2">{`.render(...)`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>:{" "}
                <mark>
                  Renders the React application into the root container.
                </mark>
              </li>
              <li className="pt-2">
                <strong>What it does</strong>:
                <ul>
                  <li className="pt-2">
                    Accepts a React element as an argument (in this case, the{" "}
                    <code>{`<StrictMode>`}</code> wrapper containing{" "}
                    <code>{`<App/>`}</code>).
                  </li>
                  <li className="pt-2">
                    Injects the rendered React content into the root container
                    in the DOM.
                  </li>
                </ul>
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"} <code className="ms-2">{`<StrictMode>`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: Wraps the App component. Enables
                additional runtime checks and warnings for development.
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"} <code className="ms-2">{`<App />`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>:{" "}
                <mark>The main component of the application.</mark>
                Serves as the starting point for your app's UI. Includes and
                renders other child components and logic.
              </li>
            </ul>
          </div>

          <h4 className="pt-3">
            The app <span className="fst-italic">creation flow</span>, in a few
            lines
          </h4>

          <div className="pb-2">
            <p className="pt-2">
              By running the <code>{`./src/main.tsx`} module,</code>
            </p>
            <ol className="pt-2">
              <li>
                The browser loads the <code>index.html</code>file, which
                contains a <code>{`<div id="root"></div>`}</code> element.
              </li>
              <li className="pt-2">
                <code>{`document.getElementById("root")!`}</code> finds this{" "}
                <code>{`<div>`}</code> in the DOM.
              </li>
              <li className="pt-2">
                <code>createRoot(...)</code> sets up React to manage this DOM
                node.
              </li>
              <li className="pt-2">
                <code>{`<StrictMode>`}</code> ensures the app runs with
                additional checks and warnings during development.
              </li>
            </ol>
            <p className="pt-2">
              Then,{" "}
              <mark>
                the application initializes by rendering the <code>App</code>{" "}
                component into the <code>#root</code> element in the HTML. React
                takes control of this DOM node, enabling dynamic and efficient
                updates to the UI.
              </mark>
            </p>
          </div>
        </div>

        <h3 className="mt-4">
          What to expect in <code>{`App`}</code>
        </h3>
        <div className="pb-2">
          <p className="pt-3">
            {" "}
            Let's have a quick look at <code>src/App.tsx</code>
          </p>

          <div className="py-2">
            <DocsCode text={appTsx} language={"typescript"} />
          </div>

          <h4 className="pt-3">
            The <code>App</code> file contents
          </h4>

          <div className="pb-2">
            <p className="pt-2">
              You might have guessed what the lines below do:
            </p>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`import "./assets/css/bootstrap.css";`}</code>
            </h5>
            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`import "./assets/css/app.css";`}</code>
            </h5>
            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`import "./assets/css/icons.css";`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: Imports the styling definition from{" "}
                <code>bootstrap.css</code>, <code>app.css</code>, and{" "}
                <code>icons.css</code> file.
              </li>
              <li className="pt-2">
                <strong>What it does</strong>: This import ensures that the
                styles in the files are added to the final bundled CSS and
                applied to your application.
              </li>
            </ul>

            <p className="pt-2">
              But what are <code>{`<AppProvider>`}</code> and{" "}
              <code>{`<AppRouter>`}</code>? What do these{" "}
              <code>{`Provider`}</code> and <code>{`Router`}</code> do, exactly?
            </p>

            <p className="pt-2">
              A <span className="fst-italic">Explain Like I'm 5</span>{" "}
              explanation for <code>{`Provider`}</code> and{" "}
              <code>{`Router`}</code> - Imagine you're building a big house 🏠.
              Here's what happens:
            </p>

            <ul className="pt-2">
              <li>
                <p>
                  <code>Provider</code>: It's like a big storage box 📦 where
                  you keep all the important tools that everyone in the house
                  can use, like batteries or scissors. This storage box can only
                  be accessed by the people who are living{" "}
                  <span className="fst-italic">in the house</span>.
                </p>
                <a
                  href="https://legacy.reactjs.org/docs/context.html"
                  target="_blank"
                  className="pb-2 d-inline"
                >
                  Learn more about React Context
                </a>
              </li>
              <li className="pt-2">
                <p>
                  <code>Router</code>: It's like a map 🗺️ of the house that
                  tells you where all the rooms are and how to get to them
                  (living room, bedroom, kitchen).
                </p>
                <a
                  href="https://reactrouter.com/start/library/routing"
                  target="_blank"
                  className="pb-2 d-inline"
                >
                  Learn more about React Router
                </a>
              </li>
            </ul>

            <p className="pt-2">So putting it together:</p>

            <ul className="pt-2">
              <li>
                <p>
                  <code>{`<AppProvider>`}</code>{" "}
                  <mark>
                    provides its childrens (i.e. the app) important things like
                    data or settings.
                  </mark>{" "}
                  The <code>{`<AppProvider>`}</code> includes the data for
                  theming (dark and light themes), navigation bar status,
                  authentication status, and more.
                </p>
                <Link
                  className="d-block"
                  to={`/docs/${DocsRoutePathname.contexts}`}
                  target="_blank"
                >
                  Learn more about App Contexts and Providers
                </Link>
              </li>
              <li className="pt-2">
                <p>
                  <code>{`<AppRouter>`}</code> directs users to the right "ride"
                  (page or feature). This component also{" "}
                  <mark>
                    keeps a directory of which component React should render for
                    a particular pathname
                  </mark>
                  (e.g. <code>{`./docs`}</code>). For example, by telling{" "}
                  <code>{`<AppRouter>`}</code> that we want to navigate to page{" "}
                  <code>{`./docs`}</code>, it will redirect current page to the{" "}
                  <code>{`./docs`}</code> page and show us the Documentation
                  site.
                </p>
                <Link
                  className="d-block"
                  to={`/docs/${DocsRoutePathname.routing}`}
                  target="_blank"
                >
                  Learn more about App Router
                </Link>
              </li>
            </ul>
          </div>

          <h4 className="pt-3">The things behind the scenes</h4>

          <div className="pb-2">
            <Link
              to={`/docs/${DocsRoutePathname.folderAndFiles}`}
              target="_blank"
              className="pt-2 d-block"
            >
              Folders and Files
            </Link>

            <p className="pt-2">
              {" "}
              Within the <code>./src</code> folder, you should see the{" "}
              <code>firebase.ts</code> file. The <code>README.md</code> file
              should have shown you how to setup <code>firebase</code> config,
              which is vital for authentication functionalities of our
              application.
            </p>

            <div className="py-2">
              <DocsCode text={firebaseTs} language="typescript" />
            </div>

            <p className="pt-2">
              The line 14 and 15 are very important for setting up the{" "}
              <code>firebase</code> environment, allow us to let user log in,
              sign up and log out of our application.
            </p>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`initializeApp(firebaseConfig);`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: Initialise the Firebase SDK along with
                the configuration defined in <code>firebaseConfig</code>
              </li>
            </ul>

            <h5 className="pt-2">
              {">>"}{" "}
              <code className="ms-2">{`export const appAuth = getAuth(app);`}</code>
            </h5>

            <ul className="py-2">
              <li>
                <strong>Purpose</strong>: <code>getAuth</code> is a function
                from the Firebase Authentication SDK that initializes and
                retrieves the authentication service for your Firebase app.
              </li>
            </ul>

            <p className="pt-2">How the Firebase SDK is initialised:</p>

            <ul className="pt-2">
              <li>
                The <code>firebase.ts</code> file is included in the dependency
                graph (a.k.a. the files/scripts that the app needs to run). Vite
                then processes this file, along with all its imports.
              </li>
              <li className="pt-2">
                The React app starts, and the entry point (main.tsx) runs. If a
                component or module in your app imports something from
                firebase.ts, the firebase.ts file is executed.
              </li>
              <li className="pt-2">
                Firebase services (e.g., Firestore or Auth) are initialized with
                your configuration.
              </li>
              <li className="pt-2">
                The <code>firebase.ts</code> file is executed only once when it
                is imported for the first time, thanks to JavaScript's module
                caching. Firebase services initialized in firebase.ts are reused
                wherever they are imported, ensuring consistency across your
                app. This includes the authentication service, i.e.{" "}
                <code>appAuth</code>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const ApplicationSetupPage = Page;

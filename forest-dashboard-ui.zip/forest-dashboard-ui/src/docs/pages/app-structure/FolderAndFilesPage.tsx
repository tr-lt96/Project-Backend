import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";
import { Table } from "../../../components/ui-elements";
import { Link } from "react-router-dom";
import { DocsRoutePathname } from "../../components/page-header/docs-route-map";

const topFolders = `.
└── src/
    ├── assets/
    ├── components/
    ├── docs/
    ├── functions/
    ├── hooks/
    ├── mocks/
    ├── pages/
    ├── types/
    └── utils/`;

const topFiles = `.
├── .gitignore
├── eslint.config.js
├── index.html
├── package.json
├── package-lock.json
├── tsconfig.app.json
├── tsconfig.json
├── tsconfig.node.json
└── vite.config.ts`;

const srcFolderFiles = `.
└── src/
    ├── App.tsx
    ├── firebase.ts
    └── main.tsx`;

const Page = () => {
  return (
    <DocsPageLayout title="Folder and files">
      <div className="col-12">
        <div className="pb-2">
          <Card>
            <Card.Body>
              <p className="my-2 lh-base">
                This section aims to provide a quick understanding about the
                project structure.
              </p>
            </Card.Body>
          </Card>
        </div>

        <h3 className="mt-4">
          The <code>src</code> folder
        </h3>
        <div className="pb-2 border-bottom">
          <p className="py-2">
            Top-level folders are used to organize your application's code and
            static assets. The <code>src</code> folder contains most of the
            application code.
          </p>

          <h4 className="pt-3">
            The folders in <code>src</code>
          </h4>
          <div className="pb-2">
            <div className="pt-2">
              <Card>
                <Card.Body>
                  <pre>
                    <code>{topFolders}</code>
                  </pre>
                </Card.Body>
              </Card>
            </div>

            <p className="py-2">
              The table below explains the definition and purpose of each folder
              within <code>src</code> folder
            </p>
            <SrcFolderTable />
          </div>

          <h4 className="pt-3">
            The files in <code>src</code>
          </h4>
          <div className="pb-2">
            <div className="pt-2">
              <Card>
                <Card.Body>
                  <pre>
                    <code>{srcFolderFiles}</code>
                  </pre>
                </Card.Body>
              </Card>
            </div>

            <p className="py-2">
              The table below explains the definition and purpose of each files
              at the root of <code>src</code> folder
            </p>
            <SrcFiles />

            <Link
              className="pb-2 d-block"
              to={`/docs/${DocsRoutePathname.applicationSetup}`}
              target="_blank"
            >
              Learn more about how application is set up.
            </Link>
          </div>
        </div>

        <h3 className="mt-4">The top level files</h3>
        <div className="pb-2">
          <p className="py-2">
            Top-level files are used to configure your application, manage
            dependencies, and define environment variables.
          </p>
          <Card>
            <Card.Body>
              <pre>
                <code>{topFiles}</code>
              </pre>
            </Card.Body>
          </Card>

          <p className="mt-4 mb-3">
            The table below explains the definition and purpose of each
            top-level files
          </p>
          <TopLevelFiles />
        </div>
      </div>
    </DocsPageLayout>
  );
};

function SrcFolderTable() {
  const headers = ["Folder", "Description"];

  const items = [
    {
      name: "assets/",
      description:
        "Contains the css (styling) files and font files for the whole web application",
    },
    {
      name: "components/",
      description:
        "Contains the UI building blocks of the applications (e.g. buttons, navigation bars, forms, etc.), contexts ( components that provide data to the entire tree below it)",
    },
    {
      name: "docs/",
      description:
        "Contains the components for documentation site (i.e. the whole ./docs site lives here)",
    },
    {
      name: "functions/",
      description:
        "Contains the utility functions that are used in various places in the code base.",
    },
    {
      name: "hooks/",
      description: (
        <>
          Contains the utility hooks (see{" "}
          <a
            href="https://legacy.reactjs.org/docs/hooks-overview.html"
            target="_blank"
          >
            https://legacy.reactjs.org/docs/hooks-overview.html
          </a>
          )
        </>
      ),
    },
    {
      name: "mocks/",
      description:
        "Contains mock functions and datas for testing and demo purposes.",
    },
    {
      name: "pages/",
      description: (
        <>
          Contains the page components for each route (for example,
          DashboardPage is the page for route <code>/dashboard</code>)
        </>
      ),
    },
    {
      name: "types/",
      description:
        "Contains common types' definition (e.g type of user, transaction data, etc.)",
    },
    {
      name: "utils/",
      description:
        "Contains utility components and constants that are vital to the app, such as app router and route error codes (e.g 404 not found)",
    },
  ].map((item) => {
    return {
      ...item,
      name: <code>{item.name}</code>,
    };
  });

  return <Table headers={headers} items={items} id="src-folder-desc" />;
}

function TopLevelFiles() {
  const headers = ["Folder", "Description"];

  const items = [
    {
      name: ".gitignore",
      description:
        "Contains the list of file that should not be tracked by git and should not be pushed to the remote repository",
    },
    {
      name: "eslint.config.js",
      description: (
        <>
          Configuration file for ESLint (see{" "}
          <a href="https://eslint.org/" target="_blank">
            https://eslint.org/
          </a>
          )
        </>
      ),
    },
    {
      name: "index.html",
      description: "Entry point and the HTML container for the web application",
    },
    {
      name: "package.json",
      description:
        "Contains information such as the project's name, version, author, license, and dependency libraries (the application will need these libraries to run)",
    },
    {
      name: "package-lock.json",
      description:
        "A generated file that records the exact versions of all libraries and their dependencies that are installed and stored in node_modules",
    },
    {
      name: "tsconfig.app.json",
      description:
        "Configuration file for rendering typescript for web components. (i.e. react components)",
    },
    {
      name: "tsconfig.node.json",
      description:
        "Configuration file for Vite engine's environment. This file should not be changed.",
    },
    {
      name: "vite.config.ts",
      description: "Configuration file for Vite.",
    },
  ].map((item) => {
    return {
      ...item,
      name: <code>{item.name}</code>,
    };
  });

  return <Table id="top-level-files" headers={headers} items={items} />;
}

function SrcFiles() {
  const headers = ["Files", "Description"];

  const items = [
    {
      name: "App.tsx",
      description:
        "Contains the code for the main component of our application.",
    },
    {
      name: "main.tsx",
      description:
        "The file that serves as the entry point of the application. It is where the React application is initialized and rendered to the DOM.",
    },
    {
      name: "firebase.ts",
      description:
        "The firebase.ts file is responsible for importing the Firebase SDK, configuring the Firebase app with your project’s credentials and exporting Firebase services (like Firestore, Authentication, or Storage) for use across the app",
    },
  ].map((item) => {
    return {
      ...item,
      name: <code>{item.name}</code>,
    };
  });

  return <Table id="src-files" headers={headers} items={items} />;
}
export const FolderAndFilesPage = Page;

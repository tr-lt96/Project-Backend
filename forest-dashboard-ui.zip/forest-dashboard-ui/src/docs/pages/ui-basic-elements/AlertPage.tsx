import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";
import {
  BasicAlertLevelColorList,
  Table,
  Alert,
} from "../../../components/ui-elements";
import { DocsCode } from "../../components/code-block/DocsCode";

const basicAlertCode = `
import { Alert } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleAlert = () => {
    return (
        <Alert
            message={"This is a sample message"}
            level={"success"}
        />
    )
}
`;

const alertCustomClassCode = `
import { Alert } from "../../../components/ui-elements/alert/Alert" // Relative path to the components/ui-elements folder

export const SampleAlert = () => {
    return (
        <Alert
            message={"This is a sample message"}
            level={"info"}
            className={"w-50"}
        />
    )
}
`;

function PropsTable() {
  const headers = ["Name", "Type", "Required", "Description"];

  const items = [
    {
      name: "message",
      type: <code>string</code>,
      required: true,
      description: "Alert message",
    },
    {
      name: "level",
      type: (
        <span>
          <code>info</code>, <code>success</code>, <code>warning</code> or{" "}
          <code>danger</code>
        </span>
      ),
      required: true,
      description: "Alert level",
    },
    {
      name: "className",
      type: <code>string</code>,
      required: false,
      description: "Additional class name for component",
    },
    {
      name: (
        <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes">
          Other HTML Properties
        </a>
      ),
      type: <code>React.BaseHTMLAttribute</code>,
      required: false,
      description: "Other HTML basic properties",
    },
  ].map((item) => {
    return {
      ...item,
      required: <code>{String(item.required)}</code>,
    };
  });

  return <Table id="alert-properties" headers={headers} items={items} />;
}

const Page = () => {
  return (
    <DocsPageLayout title="Alert">
      <div className="col-12">
        <div className="pb-2">
          <Card>
            <Card.Body>
              <p className="my-2 lh-base">
                Alerts give users brief and potentially time-sensitive
                information in an unobtrusive manner.
              </p>
            </Card.Body>
          </Card>
        </div>

        <h3 className="mt-4">Usage</h3>

        <div className="pb-2">
          <p className="pt-2">
            You can toggle light and dark theme to see how the component would
            appear in light and dark mode.
          </p>

          <div className="pt-2">
            {BasicAlertLevelColorList.map((level) => (
              <Alert
                message={`This is a sample ${level} message`}
                level={level}
              />
            ))}
          </div>

          <div className="py-2">
            <DocsCode text={basicAlertCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also add additional styling to the component, and/or
            additional styling class. For example, you can add <code>w-50</code>{" "}
            to set the width of the element to 50% of container size.
          </p>

          <div className="pt-2">
            <Alert
              message={`This is a sample message`}
              level={"info"}
              className={"w-50"}
            />
          </div>

          <div className="py-2">
            <DocsCode text={alertCustomClassCode} language="typescript" />
          </div>

          <h4 className="pt-3">Properties</h4>
          <div className="py-2">
            <PropsTable />
          </div>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const AlertPage = Page;

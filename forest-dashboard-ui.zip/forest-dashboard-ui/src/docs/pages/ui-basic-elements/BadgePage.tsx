import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";
import { Badge, BasicColorList, Table } from "../../../components/ui-elements";
import { DocsCode } from "../../components/code-block/DocsCode";

const basicBadgeCode = `
import { Badge } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleBadge = () => {
    return (
        <Badge label="Test" color={"primary"}/>
    )
}
`;

const badgeVariantCode = `
import { Badge } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleBadge = () => {
    return (
        <Badge label="Test" color={"primary"} variant={"solid"}/> // variant can be solid, subtle or outlined
    )
}
`;

const badgeCustomClassCode = `
import { Badge } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleBadge = () => {
    return (
        <Badge label="Test" color={"primary"} variant={"solid"} className="px-4"/> // variant can be solid, subtle or outlined
    )
}
`;

function PropsTable() {
  const headers = ["Name", "Type", "Required", "Description"];

  const items = [
    {
      name: "label",
      type: <code>string</code>,
      required: true,
      description:
        "Badge content, either a label or a number that has converted to string",
    },
    {
      name: "color",
      type: (
        <span>
          {BasicColorList.map((color, idx) =>
            idx < BasicColorList.length - 1 ? (
              <>
                <code>{color}</code>,{" "}
              </>
            ) : (
              <>
                or <code>{color}</code>
              </>
            )
          )}
        </span>
      ),
      required: false,
      description: "Badge color",
    },
    {
      name: "variant",
      type: (
        <span>
          <code>subtle</code>, <code>solid</code>, or <code>outlined</code>
        </span>
      ),
      required: false,
      description: "Badge style",
    },
    {
      name: "className",
      type: <code>string</code>,
      required: false,
      description: "Additional class name for component",
    },
    {
      name: (
        <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes">
          Other HTML Properties
        </a>
      ),
      type: <code>React.BaseHTMLAttribute</code>,
      required: false,
      description: "Other HTML basic properties",
    },
  ].map((item) => {
    return {
      ...item,
      required: <code>{String(item.required)}</code>,
    };
  });

  return <Table id="badge-properties" headers={headers} items={items} />;
}

const Page = () => {
  return (
    <DocsPageLayout title="Badge">
      <div className="col-12">
        <div className="pb-2">
          <Card>
            <Card.Body>
              <p className="my-2 lh-base">
                Badge is a small chip element that display a number or a short
                text that represents status or number count.
              </p>
            </Card.Body>
          </Card>
        </div>

        <h3 className="mt-4">Usage</h3>

        <div className="pb-2">
          <p className="pt-2">
            You can toggle light and dark theme to see how the component would
            appear in light and dark mode. By default, <code>Badge</code> will
            have "subtle" style (style with transparent background and solid
            text).
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                {BasicColorList.map((color) => (
                  <Badge label="Test" color={color} className="ms-1" />
                ))}
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={basicBadgeCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also choose different variant for Badge component
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <h5>
                  <strong>Subtle</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <Badge label="Test" color={color} className="ms-1" />
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Solid</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <Badge
                    label="Test"
                    color={color}
                    variant={"solid"}
                    className="ms-1"
                  />
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Outlined</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <Badge
                    label="Test"
                    color={color}
                    variant={"outlined"}
                    className="ms-1"
                  />
                ))}
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={badgeVariantCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also add additional styling to the component, and/or
            additional styling class. For example, you can change badge padding
            by set <code>className</code> property with "px-4". Note that you
            can't change font or text style.
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <Badge
                  label="Test"
                  color={"primary"}
                  variant="solid"
                  className="px-4"
                />
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={badgeCustomClassCode} language="typescript" />
          </div>

          <h4 className="pt-3">Properties</h4>
          <div className="py-2">
            <PropsTable />
          </div>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const BadgePage = Page;

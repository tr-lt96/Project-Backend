// import { Card, Form } from "react-bootstrap";
// import { DocsPageLayout } from "../../components/DocsPageLayout";
// import {
//   Icon,
//   BasicColorList,
//   Table,
//   TextColor,
//   IconMap,
//   FormError,
// } from "../../../components/ui-elements";
// import { DocsCode } from "../../components/code-block/DocsCode";
// import { useMemo, useState } from "react";
// import { useForm } from "react-hook-form";

// const basicIconCode = `
// import { Icon } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

// export const SampleIcon = () => {
//     return (
//         <Icon iconName={"IconoirFlower"} />
//     )
// }
// `;

// const iconVariantCode = `
// import { Icon } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

// export const SampleIcon = () => {
//     return (
//         <Icon
//           color={"blue"}
//           iconName={"IconoirMail"}
//         /> // variant can be solid, soft, outlined, transparent
//     )
// }
// `;

// const iconCustomSizeCode = `
// import { Icon } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

// export const SampleIcon = () => {
//     return (
//         <IconButton
//           color={"blue"}
//           iconName={"IconoirMail"}
//           size={16}
//         />
//     )
// }
// `;

// const IconColorList = [
//   ...BasicColorList,
//   "muted",
//   "black-50",
//   "white-50",
//   "body-secondary",
//   "body-tertiary",
//   "body-emphasis",
// ];

// function PropsTable() {
//   const headers = ["Name", "Type", "Required", "Description"];

//   const items = [
//     {
//       name: "iconName",
//       type: "string",
//       required: true,
//       description: (
//         <span>
//           Icon name to be displayed. For valid icon list, see the below section
//           "Icon list"
//         </span>
//       ),
//     },
//     {
//       name: "color",
//       type: (
//         <span>
//           {IconColorList.map((color) => (
//             <code>{color}</code>
//           ))}
//         </span>
//       ),
//       required: false,
//       description: "Icon color",
//     },
//     {
//       name: "size",
//       type: <code>number</code>,
//       required: false,
//       description:
//         "The icon size. Minimum size allowed is 9 and maximum is 30.",
//     },
//     {
//       name: "className",
//       type: <code>string</code>,
//       required: false,
//       description:
//         "Additional class name for component (the container of the icon)",
//     },
//     {
//       name: "iconSx",
//       type: <code>React.CSSProperties</code>,
//       required: false,
//       description: "Custom styling property for the icon.",
//     },
//   ].map((item) => {
//     return {
//       ...item,
//       required: <code>{String(item.required)}</code>,
//     };
//   });

//   return <Table id="icon-properties" headers={headers} items={items} />;
// }

// function IconsTable() {
//   const iconList = Object.keys(IconMap);
//   const [result, setResult] = useState<string[]>([]);

//   const {
//     register,
//     handleSubmit,
//     formState: { errors },
//   } = useForm<{ searchInput: string }>({
//     defaultValues: {
//       searchInput: "",
//     },
//   });

//   const getSearchIcon = (key: string) => {
//     const matchingKey = key.toLowerCase();
//     const resultIcons = iconList.filter((iconName) =>
//       iconName.toLowerCase().includes(matchingKey)
//     );

//     setResult(resultIcons);
//   };

//   return (
//     <div>
//       <Form.Group className="mb-3" controlId="email">
//         <Form.Label>Email</Form.Label>
//         <Form.Control type="text" placeholder="Enter email" />
//       </Form.Group>
//     </div>
//   );
// }

// const Page = () => {
//   return (
//     <DocsPageLayout title="Icon">
//       <div className="col-12">
//         <div className="pb-2">
//           <Card>
//             <Card.Body>
//               <p className="my-2 lh-base">Ready-to-use Icons</p>
//             </Card.Body>
//           </Card>
//         </div>

//         <h3 className="mt-4">Usage</h3>

//         <div className="pb-2 border-bottom">
//           <p className="pt-2 ">
//             You can toggle light and dark theme to see how the component would
//             appear in light and dark mode.
//           </p>

//           <div className="pt-2">
//             <Card>
//               <Card.Body>
//                 <Icon iconName={"IconoirFlower"} />
//               </Card.Body>
//             </Card>
//           </div>

//           <div className="py-2">
//             <DocsCode text={basicIconCode} language="typescript" />
//           </div>

//           <p className="pt-4">
//             You can also choose different color for <code>Icon</code> component
//           </p>

//           <div className="pt-2">
//             <Card>
//               <Card.Body>
//                 {IconColorList.map((color) => (
//                   <Icon
//                     color={color as TextColor}
//                     iconName={"IconoirMail"}
//                     className="ms-1"
//                   />
//                 ))}
//               </Card.Body>
//             </Card>
//           </div>

//           <div className="py-2">
//             <DocsCode text={iconVariantCode} language="typescript" />
//           </div>

//           <p className="pt-4">
//             You can also change size of the icon in Icon by setting{" "}
//             <code>size</code> to a specific number. By default, icon has size
//             24.
//           </p>

//           <div className="pt-2">
//             <Card>
//               <Card.Body>
//                 {[16, 24, 32].map((size) => (
//                   <Icon
//                     color={"primary"}
//                     iconName={"IconoirMail"}
//                     className="ms-1"
//                     size={size}
//                   />
//                 ))}
//               </Card.Body>
//             </Card>
//           </div>

//           <div className="py-2">
//             <DocsCode text={iconCustomSizeCode} language="typescript" />
//           </div>

//           <h4 className="pt-3">Properties</h4>
//           <div className="py-2">
//             <PropsTable />
//           </div>
//         </div>

//         <h3 className="mt-4">Icon List</h3>
//       </div>
//     </DocsPageLayout>
//   );
// };

// export const IconPage = Page;

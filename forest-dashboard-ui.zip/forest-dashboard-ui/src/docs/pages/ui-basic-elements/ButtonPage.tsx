import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../../components/DocsPageLayout";
import {
  Button,
  BasicColorList,
  Table,
  Icon,
  IconButton,
} from "../../../components/ui-elements";
import { DocsCode } from "../../components/code-block/DocsCode";
import { DocsRoutePathname } from "../../components/page-header/docs-route-map";
import { Link } from "react-router-dom";

const basicButtonCode = `
import { Button } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <Button>Test button</Button>
    )
}
`;

const buttonVariantCode = `
import { Button } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <Button color={"blue"} variant="soft">
          Test
        </Button> // variant can be solid, soft or outlined
    )
}
`;

const buttonCustomClassCode = `
import { Button } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <Button color={"primary"} className="ms-1 px-4" variant="soft">
          <span className="display-2">Test</span>
        </Button>
    )
}
`;

const buttonWithIconCode = `
import { Button, Icon } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <Button
          color="primary"
          variant="solid"
          type="submit"
          className="d-flex align-items-center justify-content-center"
        >
          Test button with icon
          <Icon iconName={"FaSignInAlt"} size={16} className="ms-1" />
        </Button>
    )
}
`;

const basicIconButtonCode = `
import { IconButton } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <IconButton iconName={"IconoirFlower"} />
    )
}
`;

const iconButtonVariantCode = `
import { IconButton } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <IconButton
          color={"blue"}
          iconName={"IconoirMail"}
          variant="solid"
        /> // variant can be solid, soft, outlined, transparent
    )
}
`;

const iconButtonCustomSizeCode = `
import { IconButton } from "../../../components/ui-elements" // Relative path to the components/ui-elements folder

export const SampleButton = () => {
    return (
        <IconButton
          color={"blue"}
          iconName={"IconoirMail"}
          variant="solid"
          size={16}
        /> 
    )
}
`;

function ButtonPropsTable() {
  const headers = ["Name", "Type", "Required", "Description"];

  const items = [
    {
      name: "children",
      type: <code>React.ReactNode</code>,
      required: true,
      description: "Button content, can be text, number, or a HTML element",
    },
    {
      name: "color",
      type: (
        <span>
          {BasicColorList.map((color, idx) =>
            idx < BasicColorList.length - 1 ? (
              <>
                <code>{color}</code>,{" "}
              </>
            ) : (
              <>
                or <code>{color}</code>
              </>
            )
          )}
        </span>
      ),
      required: false,
      description: "Button color",
    },
    {
      name: "variant",
      type: (
        <span>
          <code>soft</code>, <code>solid</code>, or <code>outlined</code>
        </span>
      ),
      required: false,
      description: "Button style",
    },
    {
      name: "className",
      type: <code>string</code>,
      required: false,
      description: "Additional class name for component",
    },
    {
      name: (
        <Link to="https://html.spec.whatwg.org/multipage/form-elements.html#the-button-element">
          Other HTML Button Properties
        </Link>
      ),
      type: <code>React.ButtonHTMLAttributes</code>,
      required: false,
      description: "Other HTML button properties, like onClick, onSubmit etc.",
    },
  ].map((item) => {
    return {
      ...item,
      required: <code>{String(item.required)}</code>,
    };
  });

  return <Table id="button-properties" headers={headers} items={items} />;
}

function IconButtonPropsTable() {
  const headers = ["Name", "Type", "Required", "Description"];

  const items = [
    {
      name: "iconName",
      type: "string",
      required: true,
      description: (
        <span>
          Icon name to be displayed. For valid icon list, see{" "}
          <Link
            className="d-inline"
            to={`/docs/${DocsRoutePathname.icon}`}
            target="_blank"
          >
            Icon page
          </Link>
        </span>
      ),
    },
    {
      name: "color",
      type: (
        <span>
          {BasicColorList.map((color, idx) =>
            idx < BasicColorList.length - 1 ? (
              <>
                <code>{color}</code>,{" "}
              </>
            ) : (
              <>
                or <code>{color}</code>
              </>
            )
          )}
        </span>
      ),
      required: false,
      description: "Button color",
    },
    {
      name: "variant",
      type: (
        <span>
          <code>soft</code>, <code>solid</code>, <code>outlined</code>, or{" "}
          <code>transparent</code>
        </span>
      ),
      required: false,
      description: "Button style",
    },
    {
      name: "size",
      type: <code>number</code>,
      required: false,
      description:
        "The icon size. Minimum size allowed is 9 and maximum is 30.",
    },
    {
      name: "className",
      type: <code>string</code>,
      required: false,
      description:
        "Additional class name for component (the container of the icon)",
    },
    {
      name: "iconSx",
      type: <code>React.CSSProperties</code>,
      required: false,
      description: "Custom styling property for the icon.",
    },
    {
      name: (
        <Link to="https://html.spec.whatwg.org/multipage/form-elements.html#the-button-element">
          Other HTML Button Properties
        </Link>
      ),
      type: <code>React.ButtonHTMLAttributes</code>,
      required: false,
      description: "Other HTML button properties, like onClick, onSubmit etc.",
    },
  ].map((item) => {
    return {
      ...item,
      required: <code>{String(item.required)}</code>,
    };
  });

  return <Table id="icon-button-properties" headers={headers} items={items} />;
}

const Page = () => {
  return (
    <DocsPageLayout title="Button">
      <div className="col-12">
        <div className="pb-2">
          <Card>
            <Card.Body>
              <p className="my-2 lh-base">
                <code>Button</code> allow users to take actions, and make
                choices, with a single tap. <code>IconButton</code> is a variant
                of button of which content is a single Icon
              </p>
            </Card.Body>
          </Card>
        </div>

        <h3 className="mt-4">Button Usage</h3>
        <div className="pb-2 border-bottom">
          <p className="pt-2">
            You can toggle light and dark theme to see how the component would
            appear in light and dark mode. By default, <code>Button</code> will
            have "soft" style (style with transparent background and solid
            text).
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <Button>Test button</Button>
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={basicButtonCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also choose different variant for Button component
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <h5>
                  <strong>Soft</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <Button color={color} className="ms-1" variant="soft">
                    Test
                  </Button>
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Solid</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <Button color={color} className="ms-1" variant="solid">
                    Test
                  </Button>
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Outlined</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <Button color={color} className="ms-1" variant="outlined">
                    Test
                  </Button>
                ))}
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={buttonVariantCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also add additional styling to the component, and/or
            additional styling class. For example, you can change button padding
            by set <code>className</code> property with "px-4". The content of{" "}
            <code>Button</code> can also be anything, as long as they are valid
            HTML Element or text/number.
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <Button color={"primary"} className="ms-1 px-4" variant="soft">
                  <span className="display-2">Test</span>
                </Button>
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={buttonCustomClassCode} language="typescript" />
          </div>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <Button
                  color="primary"
                  variant="solid"
                  type="submit"
                  className="d-flex align-items-center justify-content-center"
                >
                  Test button with icon
                  <Icon iconName={"FaSignInAlt"} size={16} className="ms-1" />
                </Button>
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={buttonWithIconCode} language="typescript" />
          </div>

          <h4 className="pt-3">Properties</h4>
          <div className="py-2">
            <ButtonPropsTable />
          </div>
        </div>

        <h3 className="mt-4">Icon Button Usage</h3>
        <div className="pb-2">
          <p className="pt-2">
            You can toggle light and dark theme to see how the component would
            appear in light and dark mode. By default, <code>IconButton</code>{" "}
            will have "soft" style (style with transparent background and solid
            text).
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <IconButton iconName={"IconoirFlower"} />
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={basicIconButtonCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also choose different variants and color for{" "}
            <code>IconButton</code> component
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                <h5>
                  <strong>Soft</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <IconButton
                    color={color}
                    iconName={"IconoirMail"}
                    className="ms-1"
                  />
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Solid</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <IconButton
                    color={color}
                    iconName={"IconoirMail"}
                    className="ms-1"
                    variant="solid"
                  />
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Outlined</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <IconButton
                    color={color}
                    iconName={"IconoirMail"}
                    className="ms-1"
                    variant="outlined"
                  />
                ))}
              </Card.Body>
              <Card.Body>
                <h5>
                  <strong>Transparent</strong>
                </h5>
                {BasicColorList.map((color) => (
                  <IconButton
                    color={color}
                    iconName={"IconoirMail"}
                    className="ms-1"
                    variant="transparent"
                  />
                ))}
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={iconButtonVariantCode} language="typescript" />
          </div>

          <p className="pt-4">
            You can also change size of the icon in IconButton by setting{" "}
            <code>size</code> to a specific number. By default, icon has size
            24.
          </p>

          <div className="pt-2">
            <Card>
              <Card.Body>
                {[16, 24, 32].map((size) => (
                  <IconButton
                    color={"primary"}
                    iconName={"IconoirMail"}
                    className="ms-1"
                    size={size}
                  />
                ))}
              </Card.Body>
            </Card>
          </div>

          <div className="py-2">
            <DocsCode text={iconButtonCustomSizeCode} language="typescript" />
          </div>

          <h4 className="pt-3">Properties</h4>
          <div className="py-2">
            <IconButtonPropsTable />
          </div>
        </div>
      </div>
    </DocsPageLayout>
  );
};

export const ButtonPage = Page;

import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../components/DocsPageLayout";
import { Link } from "react-router-dom";
import { DocsRoutePathname } from "../components/page-header/docs-route-map";

const Page = () => {
  <DocsPageLayout title="Alert">
    <div className="col-12">
      <div className="pb-2">
        <Card>
          <Card.Body>
            <p className="my-2 lh-base">
              This section aims to provide a quick understanding about the
              project structure.
            </p>
          </Card.Body>
        </Card>
      </div>

      <h3 className="pt-3">
        The <code>src</code> folder
      </h3>
      <div className="pb-2">
        <p className="py-2">
          Top-level folders are used to organize your application's code and
          static assets. The <code>src</code> folder contains most of the
          application code.
        </p>

        <h4 className="pt-3">
          The folders in <code>src</code>
        </h4>
        <div className="pb-2">
          <div className="pt-2">
            <Card>
              <Card.Body>
                <pre>
                  <code>{`Sample code`}</code>
                </pre>
              </Card.Body>
            </Card>
          </div>

          <p className="py-2">
            The table below explains the definition and purpose of each folder
            within <code>src</code> folder
          </p>
        </div>

        <h4 className="pt-3">
          The files in <code>src</code>
        </h4>
        <div className="pb-2">
          <div className="pt-2">Test</div>

          <p className="py-2">
            The table below explains the definition and purpose of each files at
            the root of <code>src</code> folder
          </p>

          <Link
            className="d-block"
            to={`/docs/${DocsRoutePathname.applicationSetup}`}
            target="_blank"
          >
            Learn more about how application is set up.
          </Link>
        </div>
      </div>

      <h3 className="pt-3">The top level files</h3>
      <div>
        <p className="py-2">
          Top-level files are used to configure your application, manage
          dependencies, and define environment variables.
        </p>

        <p className="mt-4 mb-3">
          The table below explains the definition and purpose of each top-level
          files
        </p>
      </div>
    </div>
  </DocsPageLayout>;
};

export default Page;

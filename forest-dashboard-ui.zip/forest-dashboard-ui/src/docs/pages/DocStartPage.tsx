import { Card } from "react-bootstrap";
import { DocsPageLayout } from "../components/DocsPageLayout";

export const DocStartPage = () => {
  return (
    <DocsPageLayout title="Docs start page">
      <div className="col-12">
        <Card>
          <Card.Body>
            <h2 className="my-2">Welcome to Forest Dashboard Documentation!</h2>
            <p className="mt-3 lh-base">
              Welcome to Forest Dashboard Documentation! Whether you're a
              seasoned software wizard or a curious Muggle looking to explore,
              this documentation is your trusty Marauder's Map to mastering our
              platform.
            </p>
          </Card.Body>
        </Card>
      </div>
    </DocsPageLayout>
  );
};

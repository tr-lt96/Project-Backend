import { useLocation } from "react-router-dom";
import { Breadcrumb, BreadcrumbItem } from "react-bootstrap";
import { useMemo } from "react";
import { ValidPathSegments } from "../../../utils/router";

interface IPageHeaderProps {
  title: string;
}

export const PageHeader = ({ title }: IPageHeaderProps) => {
  const { pathname } = useLocation();
  const breadCrumbs = useMemo(
    () =>
      ("app/" + pathname)
        .split("/")
        .filter((pn) => ValidPathSegments.includes(pn))
        .map((pn) => pn[0].toUpperCase() + pn.substring(1).toLowerCase()),
    []
  );

  const BreadCrumbItems = () => {
    return breadCrumbs.map((breadCrumb, index) => {
      const key = `breadcrumb-${breadCrumb}-${index}`;
      return <BreadcrumbItem key={key}>{breadCrumb}</BreadcrumbItem>;
    });
  };

  return (
    <div className="row">
      <div className="col-sm-12">
        <div className="page-title-box d-md-flex justify-content-md-between align-items-center">
          <h4 className="page-title">{title}</h4>
          <Breadcrumb as="div">
            <BreadCrumbItems />
          </Breadcrumb>
        </div>
      </div>
    </div>
  );
};

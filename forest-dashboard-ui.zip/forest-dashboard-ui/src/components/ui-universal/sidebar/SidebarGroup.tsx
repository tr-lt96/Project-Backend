import { Nav } from "react-bootstrap";
import { SidebarMenuGroup as ISidebarGroupProps } from "./sidebar-map";
import { SidebarItem } from "./SidebarItem";

export const SidebarGroup = ({ groupLabel, items }: ISidebarGroupProps) => {
  if (!items || items.length === 0) {
    return null;
  }

  const SidebarItems = () => {
    return items.map((item, index) => {
      const key = `sidebar-item-${item.label}-${index}`;
      return <SidebarItem key={key} {...item} />;
    });
  };

  return (
    <Nav as="ul" className="navbar-nav mb-auto w-100">
      <li className="menu-label mt-2">
        <span>{groupLabel}</span>
      </li>
      <SidebarItems />
    </Nav>
  );
};

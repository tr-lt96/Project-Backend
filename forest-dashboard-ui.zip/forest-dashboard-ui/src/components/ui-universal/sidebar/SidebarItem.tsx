import { Collapse, Nav } from "react-bootstrap";
import { SidebarMenuItem as ISidebarMenuItemProps } from "./sidebar-map";
import { Badge, IBadgeProps, Icon, IconKey } from "../../ui-elements";
import { useState } from "react";

const SidebarItemBadges = ({ badges }: { badges?: IBadgeProps[] }) => {
  if (!badges || badges.length === 0) {
    return null;
  }

  return badges.map((badge, index) => {
    const key = `sidebar-item-badge-${badge.label}-${index}`;
    return <Badge key={key} className={"ms-1"} {...badge} />;
  });
};

const SidebarItemIcon = ({ iconName }: { iconName?: IconKey }) => {
  if (!iconName) {
    return null;
  }

  return <Icon iconName={iconName} className="menu-icon" />;
};

const SidebarItemLabel = ({
  label,
  iconName,
  badges,
}: Omit<ISidebarMenuItemProps, "subItems">) => {
  return (
    <>
      <SidebarItemIcon iconName={iconName} />
      <span>{label}</span>
      <SidebarItemBadges badges={badges} />
    </>
  );
};

export const SidebarItem = ({
  subItems,
  href,
  ...itemProps
}: ISidebarMenuItemProps) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(true);

  if (subItems && subItems.length) {
    const toggleCollapse = () => setIsCollapsed(!isCollapsed);

    /* Dropdown item components */
    const SidebarSubItems = () => {
      return (
        <Nav as="ul" className="flex-column">
          {subItems.map((subItem, index) => {
            const key = `sidebar-item-subitem-${itemProps.label}-${subItem.label}-${index}`;

            return (
              <Nav.Item key={key} as="li">
                <Nav.Link href={subItem.href}>
                  <SidebarItemLabel {...subItem} />
                </Nav.Link>
              </Nav.Item>
            );
          })}
        </Nav>
      );
    };

    return (
      <Nav.Item as="li">
        <Nav.Link
          aria-controls={"sidebarTransactions"}
          aria-expanded={!isCollapsed}
          data-bs-toggle={"collapse"}
          onClick={toggleCollapse}
        >
          <SidebarItemLabel {...itemProps} />
        </Nav.Link>
        <Collapse in={!isCollapsed}>
          <div id="sidebarTransactions">
            <SidebarSubItems />
          </div>
        </Collapse>
      </Nav.Item>
    );
  }

  return (
    <Nav.Item as="li">
      <Nav.Link href={href}>
        <SidebarItemLabel {...itemProps} />
      </Nav.Link>
    </Nav.Item>
  );
};

import { useNavbarContext } from "../../contexts/app";
import SimpleBar from "simplebar-react";
import "simplebar-react/dist/simplebar.min.css";
import { SidebarMenuGroups } from "./sidebar-map";
import { SidebarGroup } from "./SidebarGroup";

export const Sidebar = () => {
  const { closeSidebar } = useNavbarContext();
  const SidebarGroups = () => {
    return SidebarMenuGroups.map((group, index) => {
      const key = `sidebar-group-${group.groupLabel}-${index}`;
      return <SidebarGroup key={key} {...group} />;
    });
  };

  return (
    <>
      <div className="startbar d-print-none">
        <div className="brand"></div>
        <div className="startbar-menu">
          <SimpleBar className="startbar-collapse">
            <div className="d-flex align-items-start flex-column w-100">
              <SidebarGroups />
            </div>
          </SimpleBar>
        </div>
      </div>
      {/* Overlay layer for side bar */}
      <div className="startbar-overlay d-print-none" onClick={closeSidebar} />
    </>
  );
};

import { IBadgeProps, IconKey } from "../../../ui-elements";

export interface SidebarMenuItem {
  label: string;
  iconName?: IconKey;
  badges?: IBadgeProps[];
  subItems?: Omit<SidebarMenuItem, "subItems">[];
  href?: string;
}

export interface SidebarMenuGroup {
  groupLabel: string;
  items: SidebarMenuItem[];
}

export const SidebarMenuGroups: SidebarMenuGroup[] = [
  {
    groupLabel: "Main",
    items: [
      {
        label: "Dashboard",
        iconName: "IconoirReportColumns",
        href: "/dashboard",
        badges: [
          {
            label: "New",
            color: "info",
          },
        ],
      },
      {
        label: "Payment",
        iconName: "IconoirHandCash",
      },
      {
        label: "Transactions",
        iconName: "IconoirTaskList",
        subItems: [{ label: "Overview" }, { label: "Add transactions" }],
      },
      {
        label: "Cards",
        iconName: "IconoirCreditCards",
      },
      {
        label: "Taxes",
        iconName: "IconoirPlugTypeL",
      },
      {
        label: "Users",
        iconName: "IconoirGroup",
      },
      {
        label: "Chat",
        iconName: "IconoirChatBubble",
      },
      {
        label: "Contact List",
        iconName: "IconoirCommunity",
      },
      {
        label: "Calendar",
        iconName: "IconoirCalendar",
      },
      {
        label: "Invoice",
        iconName: "IconoirPasteClipboard",
      },
    ],
  },
  {
    groupLabel: "Components",
    items: [],
  },
];

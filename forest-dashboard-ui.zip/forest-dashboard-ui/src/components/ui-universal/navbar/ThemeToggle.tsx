import { useThemeContext } from "../../contexts/app/theme-context/ThemeContext";
import { IconButton } from "../../ui-elements";

export const ThemeToggle = () => {
  const { theme, toggleTheme } = useThemeContext();

  return (
    <IconButton
      onClick={toggleTheme}
      iconName={theme === "dark" ? "IconoirHalfMoon" : "IconoirSunLight"}
      className="nav-link nav-icon"
      variant={"transparent"}
      color={"light"}
    />
  );
};

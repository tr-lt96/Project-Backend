import { useAuthGuard } from "../../../hooks/account";
import { TopNavbar } from "../navbar/TopNavbar";
import { PageLoading } from "../page-loading/PageLoading";
import { Sidebar } from "../sidebar/Sidebar";

export const PageLayoutWithAuthGuard = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const { isValidating, isAuthorised } = useAuthGuard();
  if (isValidating) {
    return <PageLoading message="Preparing site..." />;
  }

  if (!isAuthorised) {
    return <PageLoading message="Navigating to authentication site..." />;
  }

  return (
    <>
      {/* This is the top navigation bar (i.e. header) */}
      <TopNavbar />
      {/* This is the side navigation bar (i.e. menu sidebar) */}
      <Sidebar />
      {/* This is the rest of page*/}
      <div className="page-wrapper">
        <div className="page-content">
          <div className="container-fluid">{children}</div>
        </div>
      </div>
    </>
  );
};

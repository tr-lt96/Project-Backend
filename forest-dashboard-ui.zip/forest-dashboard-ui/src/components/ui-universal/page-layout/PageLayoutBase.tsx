export const PageLayoutBase = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="container-xxl">
      <div className="row vh-100 d-flex justify-content-center">
        <div className="col-12 align-self-center">{children}</div>
      </div>
    </div>
  );
};

import { Spinner } from "react-bootstrap";
import { PageLayoutBase } from "../page-layout/PageLayoutBase";

export const PageLoading = ({
  message = "Loading...",
}: {
  message?: string;
}) => {
  return (
    <PageLayoutBase>
      <div
        className="mx-auto d-flex flex-column align-items-center"
        style={{ width: "fit-content" }}
      >
        <Spinner
          animation="border"
          variant="secondary"
          style={{ width: "50px", height: "50px" }}
        />
        <div className="mt-2">{message}</div>
      </div>
    </PageLayoutBase>
  );
};

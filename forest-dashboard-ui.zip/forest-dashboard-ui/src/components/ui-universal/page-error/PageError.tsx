import { PageLayoutBase } from "../page-layout/PageLayoutBase";
import { AuthCard } from "../../pages/auth/AuthCard";
import { useNavigate } from "react-router-dom";
import { RoutePathname } from "../../../utils/router";

interface IPageErrorProps {
  code: number;
  message: string;
}

export const PageError = ({ message, code }: IPageErrorProps) => {
  const navigate = useNavigate();
  const toHome = () => {
    navigate(RoutePathname.app);
  };

  return (
    <PageLayoutBase>
      <div className="row">
        <div className="col-lg-4 mx-auto">
          <AuthCard title={message}>
            <div className="col-12 text-center ex-page-content">
              <h1 className="my-2">{code}</h1>
              <div className="text-center mb-2">
                <p className="text-muted">
                  Back to{" "}
                  <span role="button" className="text-primary" onClick={toHome}>
                    main page
                  </span>
                </p>
              </div>
            </div>
          </AuthCard>
        </div>
      </div>
    </PageLayoutBase>
  );
};

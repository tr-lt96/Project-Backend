export const BasicAlertLevelColorList = [
  "success",
  "info",
  "warning",
  "danger",
] as const;

export type BasicAlertLevel = (typeof BasicAlertLevelColorList)[number];

export const BasicColorList = [
  "primary",
  "secondary",
  "success",
  "info",
  "warning",
  "danger",
  "pink",
  "purple",
  "blue",
  "light",
  "dark",
] as const;

export type BasicColor = (typeof BasicColorList)[number];

export type TextColor =
  | "primary"
  | "secondary"
  | "success"
  | "info"
  | "warning"
  | "danger"
  | "pink"
  | "purple"
  | "blue"
  | "gray"
  | "light"
  | "dark"
  | "black"
  | "white"
  | "body"
  | "muted"
  | "black-50"
  | "white-50"
  | "body-secondary"
  | "body-tertiary"
  | "body-emphasis";

export type ButtonColor =
  | "primary"
  | "secondary"
  | "success"
  | "info"
  | "warning"
  | "danger"
  | "pink"
  | "purple"
  | "blue"
  | "light"
  | "dark"
  | "outline-primary"
  | "outline-secondary"
  | "outline-success"
  | "outline-info"
  | "outline-warning"
  | "outline-danger"
  | "outline-pink"
  | "outline-purple"
  | "outline-blue"
  | "outline-light"
  | "outline-dark"
  | "soft-primary"
  | "soft-secondary"
  | "soft-success"
  | "soft-info"
  | "soft-warning"
  | "soft-danger"
  | "soft-pink"
  | "soft-purple"
  | "soft-blue"
  | "soft-light"
  | "soft-dark";

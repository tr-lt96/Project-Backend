import { ApexOptions } from "apexcharts";

export const PieChartBaseOptions: ApexOptions = {
  chart: {
    type: "pie",
  },
  stroke: {
    show: false,
  },
  dataLabels: {
    enabled: false,
    dropShadow: {
      enabled: false,
    },
    style: {
      fontFamily: "inherit",
    },
  },
  legend: {
    show: true,
    position: "bottom",
    horizontalAlign: "center",
    floating: false,
    fontSize: "14px",
    offsetX: 0,
    offsetY: 6,
  },
  responsive: [
    // {
    //   breakpoint: 600,
    //   options: {
    //     legend: {
    //       show: false,
    //     },
    //   },
    // },
  ],
};

export const DonutChartBaseOptions: ApexOptions = {
  chart: {
    type: "donut",
  },
  plotOptions: {
    pie: {
      donut: {
        size: "80%",
      },
    },
  },
  dataLabels: {
    enabled: false,
    dropShadow: {
      enabled: false,
    },
    style: {
      fontFamily: "inherit",
    },
  },
  stroke: {
    show: true,
    width: 2,
    colors: ["transparent"],
  },
  legend: {
    show: true,
    position: "bottom",
    horizontalAlign: "center",
    floating: false,
    fontSize: "14px",
    offsetX: 0,
    offsetY: 0,
  },
  responsive: [
    // {
    //   breakpoint: 600,
    //   options: {
    //     plotOptions: {
    //       donut: {
    //         customScale: 0.2,
    //       },
    //     },
    //     legend: {
    //       show: false,
    //     },
    //   },
    // },
  ],
};

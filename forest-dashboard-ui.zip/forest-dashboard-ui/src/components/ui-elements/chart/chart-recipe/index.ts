import { ApexOptions } from "apexcharts";
import { TApexChart, TApexChartBaseProps } from "../chart-type";
import { BarChartBaseOptions } from "./bar-chart";
import { DonutChartBaseOptions, PieChartBaseOptions } from "./pie-chart";

const ChartBaseOptions: Record<string, ApexOptions> = {
  bar: BarChartBaseOptions,
  pie: PieChartBaseOptions,
  donut: DonutChartBaseOptions,
};

export function mergeChartBaseOptions<T extends TApexChart>(
  type: T,
  options?: TApexChartBaseProps<T>["options"],
  subType?: TApexChartBaseProps<T>["subType"]
) {
  const chartType = (subType ? subType : type) as string;
  const baseOptions = ChartBaseOptions[chartType];

  if (!options) {
    return baseOptions;
  }

  const copyOptions = { ...baseOptions };

  for (const key in options) {
    const fieldKey = key as keyof typeof options;
    if (Array.isArray(options[fieldKey])) {
      copyOptions[fieldKey] = options[fieldKey] as never;
    } else {
      copyOptions[fieldKey] = {
        ...baseOptions[fieldKey],
        ...options[fieldKey],
      } as never;
    }
  }

  console.log(copyOptions);
  return copyOptions;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
import { ApexOptions } from "apexcharts";

type TApexDropShadow = {
  enabled?: boolean;
  top?: number;
  left?: number;
  blur?: number;
  opacity?: number;
  color?: string;
};

/**
 * Copy of PlotOptions for specifying chart-type-specific configuration.
 * See https://apexcharts.com/docs/options/plotoptions/bar/
 */
type TApexPlotOptions = {
  line?: {
    isSlopeChart?: boolean;
    colors?: {
      threshold?: number;
      colorAboveThreshold?: string;
      colorBelowThreshold?: string;
    };
  };
  area?: {
    fillTo?: "origin" | "end";
  };
  bar?: {
    horizontal?: boolean;
    columnWidth?: string | number;
    barHeight?: string | number;
    distributed?: boolean;
    borderRadius?: number;
    borderRadiusApplication?: "around" | "end";
    borderRadiusWhenStacked?: "all" | "last";
    hideZeroBarsWhenGrouped?: boolean;
    rangeBarOverlap?: boolean;
    rangeBarGroupRows?: boolean;
    isDumbbell?: boolean;
    dumbbellColors?: string[][];
    isFunnel?: boolean;
    isFunnel3d?: boolean;
    colors?: {
      ranges?: {
        from?: number;
        to?: number;
        color?: string;
      }[];
      backgroundBarColors?: string[];
      backgroundBarOpacity?: number;
      backgroundBarRadius?: number;
    };
    dataLabels?: {
      maxItems?: number;
      hideOverflowingLabels?: boolean;
      position?: string;
      orientation?: "horizontal" | "vertical";
      total?: {
        enabled?: boolean;
        formatter?(val?: string, opts?: any): string;
        offsetX?: number;
        offsetY?: number;
        style?: {
          color?: string;
          fontSize?: string;
          fontFamily?: string;
          fontWeight?: number | string;
        };
      };
    };
  };
  bubble?: {
    zScaling?: boolean;
    minBubbleRadius?: number;
    maxBubbleRadius?: number;
  };
  candlestick?: {
    colors?: {
      upward?: string | string[];
      downward?: string | string[];
    };
    wick?: {
      useFillColor?: boolean;
    };
  };
  boxPlot?: {
    colors?: {
      upper?: string | string[];
      lower?: string | string[];
    };
  };
  heatmap?: {
    radius?: number;
    enableShades?: boolean;
    shadeIntensity?: number;
    reverseNegativeShade?: boolean;
    distributed?: boolean;
    useFillColorAsStroke?: boolean;
    colorScale?: {
      ranges?: {
        from?: number;
        to?: number;
        color?: string;
        foreColor?: string;
        name?: string;
      }[];
      inverse?: boolean;
      min?: number;
      max?: number;
    };
  };
  treemap?: {
    enableShades?: boolean;
    shadeIntensity?: number;
    distributed?: boolean;
    reverseNegativeShade?: boolean;
    useFillColorAsStroke?: boolean;
    dataLabels?: { format?: "scale" | "truncate" };
    borderRadius?: number;
    colorScale?: {
      inverse?: boolean;
      ranges?: {
        from?: number;
        to?: number;
        color?: string;
        foreColor?: string;
        name?: string;
      }[];
      min?: number;
      max?: number;
    };
  };
  pie?: {
    startAngle?: number;
    endAngle?: number;
    customScale?: number;
    offsetX?: number;
    offsetY?: number;
    expandOnClick?: boolean;
    dataLabels?: {
      offset?: number;
      minAngleToShowLabel?: number;
    };
    donut?: {
      size?: string;
      background?: string;
      labels?: {
        show?: boolean;
        name?: {
          show?: boolean;
          fontSize?: string;
          fontFamily?: string;
          fontWeight?: string | number;
          color?: string;
          offsetY?: number;
          formatter?(val: string): string;
        };
        value?: {
          show?: boolean;
          fontSize?: string;
          fontFamily?: string;
          fontWeight?: string | number;
          color?: string;
          offsetY?: number;
          formatter?(val: string): string;
        };
        total?: {
          show?: boolean;
          showAlways?: boolean;
          fontFamily?: string;
          fontWeight?: string | number;
          fontSize?: string;
          label?: string;
          color?: string;
          formatter?(w: any): string;
        };
      };
    };
  };
  polarArea?: {
    rings?: {
      strokeWidth?: number;
      strokeColor?: string;
    };
    spokes?: {
      strokeWidth?: number;
      connectorColors?: string | string[];
    };
  };
  radar?: {
    size?: number;
    offsetX?: number;
    offsetY?: number;
    polygons?: {
      strokeColors?: string | string[];
      strokeWidth?: string | string[];
      connectorColors?: string | string[];
      fill?: {
        colors?: string[];
      };
    };
  };
  radialBar?: {
    inverseOrder?: boolean;
    startAngle?: number;
    endAngle?: number;
    offsetX?: number;
    offsetY?: number;
    hollow?: {
      margin?: number;
      size?: string;
      background?: string;
      image?: string;
      imageWidth?: number;
      imageHeight?: number;
      imageOffsetX?: number;
      imageOffsetY?: number;
      imageClipped?: boolean;
      position?: "front" | "back";
      dropShadow?: TApexDropShadow;
    };
    track?: {
      show?: boolean;
      startAngle?: number;
      endAngle?: number;
      background?: string | string[];
      strokeWidth?: string;
      opacity?: number;
      margin?: number;
      dropShadow?: TApexDropShadow;
    };
    dataLabels?: {
      show?: boolean;
      name?: {
        show?: boolean;
        fontFamily?: string;
        fontWeight?: string | number;
        fontSize?: string;
        color?: string;
        offsetY?: number;
      };
      value?: {
        show?: boolean;
        fontFamily?: string;
        fontSize?: string;
        fontWeight?: string | number;
        color?: string;
        offsetY?: number;
        formatter?(val: number): string;
      };
      total?: {
        show?: boolean;
        label?: string;
        color?: string;
        fontFamily?: string;
        fontWeight?: string | number;
        fontSize?: string;
        formatter?(opts: any): string;
      };
    };
    barLabels?: {
      enabled?: boolean;
      offsetX?: number;
      offsetY?: number;
      useSeriesColors?: boolean;
      fontFamily?: string;
      fontWeight?: string | number;
      fontSize?: string;
      formatter?: (barName: string, opts?: any) => string;
      onClick?: (barName: string, opts?: any) => void;
    };
  };
};

export type TApexChart = keyof TApexPlotOptions;

type TApexChartSubtype = {
  line: null;
  area: null;
  bar: null;
  pie: "donut" | "pie";
  radialBar: null;
  scatter: null;
  bubble: null;
  heatmap: null;
  candlestick: null;
  boxPlot: null;
  radar: null;
  polarArea: null;
  rangeBar: null;
  rangeArea: null;
  treemap: null;
};

export type TApexChartBaseProps<T extends TApexChart> = {
  type: T;
  options?: Omit<ApexOptions, "plotOptions"> & {
    plotOptions?: TApexPlotOptions[T];
  };
  subType?: TApexChartSubtype[T];
};

import { ApexOptions } from "apexcharts";
import { TApexChartBaseProps } from "./chart-type";
import ReactApexChart from "react-apexcharts";
import { mergeChartBaseOptions } from "./chart-recipe";

type TBarChartProps = TApexChartBaseProps<"bar">;

interface IBarChartProps extends React.HTMLAttributes<HTMLBaseElement> {
  data: ApexOptions["series"];
  options?: TBarChartProps["options"];
}

export const BarChart = ({ data, options }: IBarChartProps) => {
  const chartOptions = mergeChartBaseOptions("bar", options);

  return <ReactApexChart type="bar" series={data} options={chartOptions} />;
};

import { ApexOptions } from "apexcharts";
import { TApexChartBaseProps } from "./chart-type";
import ReactApexChart from "react-apexcharts";
import { mergeChartBaseOptions } from "./chart-recipe";

type TPieChartProps = TApexChartBaseProps<"pie">;

interface IPieChartProps extends React.HTMLAttributes<HTMLBaseElement> {
  data: ApexOptions["series"];
  options?: TPieChartProps["options"];
  subType?: TPieChartProps["subType"];
}

export const PieChart = ({
  data,
  options,
  subType = "pie",
}: IPieChartProps) => {
  const chartOptions = mergeChartBaseOptions("pie", options, subType);

  return <ReactApexChart type={subType} series={data} options={chartOptions} />;
};

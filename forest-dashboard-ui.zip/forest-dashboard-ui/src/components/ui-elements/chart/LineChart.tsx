import { ApexOptions } from "apexcharts";
import { TApexChartBaseProps } from "./chart-type";
import ReactApexChart from "react-apexcharts";
import { mergeChartBaseOptions } from "./chart-recipe";

type TLineChartProps = TApexChartBaseProps<"line">;

interface ILineChartProps extends React.HTMLAttributes<HTMLBaseElement> {
  data: ApexOptions["series"];
  options?: TLineChartProps["options"];
}

export const LineChart = ({ data, options }: ILineChartProps) => {
  const chartOptions = mergeChartBaseOptions("line", options);

  return <ReactApexChart type="line" series={data} options={chartOptions} />;
};

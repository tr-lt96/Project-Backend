import { FieldError } from "react-hook-form";

export const FormError = ({ error }: { error?: FieldError }) => {
  if (!error) {
    return null;
  }

  return <span className="invalid-feedback">{error.message}</span>;
};

import { Button } from "react-bootstrap";
import { Icon, IIconProps } from "../icon/Icon";
import { BasicColor } from "../color";

type IIconButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> &
  Omit<IIconProps, "color"> & {
    color?: BasicColor;
    variant?: "solid" | "outlined" | "soft" | "transparent";
  };

export const IconButton = ({
  iconName,
  size = 24,
  color = "primary",
  variant = "soft",
  iconSx = {},
  className = "",
  ...buttonProps
}: IIconButtonProps) => {
  const buttonStyleVariant =
    variant === "outlined" || variant === "transparent"
      ? "outline"
      : variant === "soft"
      ? "soft"
      : "";

  const buttonVariant = buttonStyleVariant
    ? `${buttonStyleVariant}-${color}`
    : color;

  const borderStyle = variant === "outlined" ? "" : "border-0";
  return (
    <Button
      {...buttonProps}
      variant={buttonVariant}
      className={`p-1 lh-0 ${borderStyle} ${className}`}
    >
      <Icon iconName={iconName} size={size} iconSx={iconSx} />
    </Button>
  );
};

import { BasicColor } from "../color";
import { Badge as BsBadge } from "react-bootstrap";
import { BadgeVariantMap } from "./badge-map";

export interface IBadgeProps extends React.BaseHTMLAttributes<HTMLElement> {
  label: string;
  color?: BasicColor;
  variant?: "solid" | "subtle" | "outlined";
  className?: string;
}

export const Badge = ({
  label,
  color = "primary",
  variant = "subtle",
  className = "",
  ...props
}: IBadgeProps) => {
  return (
    <BsBadge
      className={`${BadgeVariantMap[color][variant]} ${className}`}
      pill
      bg="skip"
      {...props}
    >
      {label}
    </BsBadge>
  );
};

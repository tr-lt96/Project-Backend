import { BasicColor } from "../color";

type TBadgeVariant = Record<
  BasicColor,
  {
    solid: string;
    subtle: string;
    outlined: string;
  }
>;

export const BadgeVariantMap: TBadgeVariant = {
  primary: {
    solid: "bg-primary",
    subtle: "bg-primary-subtle text-primary",
    outlined: "bg-transparent border border-primary text-primary",
  },
  secondary: {
    solid: "bg-secondary",
    subtle: "bg-secondary-subtle text-secondary",
    outlined: "bg-transparent border border-secondary text-secondary",
  },
  success: {
    solid: "bg-success",
    subtle: "bg-success-subtle text-success",
    outlined: "bg-transparent border border-success text-success",
  },
  info: {
    solid: "bg-info",
    subtle: "bg-info-subtle text-info",
    outlined: "bg-transparent border border-info text-info",
  },
  warning: {
    solid: "bg-warning",
    subtle: "bg-warning-subtle text-warning",
    outlined: "bg-transparent border border-warning text-warning",
  },
  danger: {
    solid: "bg-danger",
    subtle: "bg-danger-subtle text-danger",
    outlined: "bg-transparent border border-danger text-danger",
  },
  pink: {
    solid: "bg-pink",
    subtle: "bg-pink-subtle text-pink",
    outlined: "bg-transparent border border-pink text-pink",
  },
  purple: {
    solid: "bg-purple",
    subtle: "bg-purple-subtle text-purple",
    outlined: "bg-transparent border border-purple text-purple",
  },
  blue: {
    solid: "bg-blue",
    subtle: "bg-blue-subtle text-blue",
    outlined: "bg-transparent border border-blue text-blue",
  },
  light: {
    solid: "bg-light text-dark",
    subtle: "bg-light-subtle text-dark",
    outlined: "bg-transparent border border-light text-dark",
  },
  dark: {
    solid: "bg-dark",
    subtle: "bg-dark-subtle text-dark",
    outlined: "bg-transparent border border-dark text-dark",
  },
};

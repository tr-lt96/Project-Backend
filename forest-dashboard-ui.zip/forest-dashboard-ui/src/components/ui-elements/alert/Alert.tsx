import { Alert as BAlert } from "react-bootstrap";
import { BasicAlertLevel } from "../color";
import { Icon } from "../icon/Icon";
import { AlertDefaultVariantMap } from "./alert-map";

export interface IAlertProps extends React.BaseHTMLAttributes<HTMLElement> {
  message: string;
  level: BasicAlertLevel;
  className?: string;
}

export const Alert = ({ message, level, className, ...props }: IAlertProps) => {
  return (
    <BAlert className={`shadow-sm ${className}`} variant={level} {...props}>
      <div
        className={`d-inline-flex justify-content-center align-items-center thumb-xs bg-${level} rounded-circle mx-auto me-1`}
      >
        <Icon
          iconName={AlertDefaultVariantMap[level].Icon}
          className="align-self-center mb-0 text-white"
          size={12}
        />
      </div>
      {message}
    </BAlert>
  );
};

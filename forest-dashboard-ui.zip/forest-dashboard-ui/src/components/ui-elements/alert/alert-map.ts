import { BasicAlertLevel } from "../color";
import { IconKey } from "../icon/icon-map";

type TAlertDefaultVariant = Record<
  BasicAlertLevel,
  {
    Icon: IconKey;
  }
>;

export const AlertDefaultVariantMap: TAlertDefaultVariant = {
  success: {
    Icon: "FaCheck",
  },
  info: {
    Icon: "FaInfo",
  },
  warning: {
    Icon: "FaExclamation",
  },
  danger: {
    Icon: "FaXmark",
  },
};

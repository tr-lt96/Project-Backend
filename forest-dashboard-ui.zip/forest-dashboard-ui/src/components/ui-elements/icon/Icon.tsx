import { TextColor } from "../color";
import { IconKey, IconMap } from "./icon-map";

export interface IIconProps {
  iconName: IconKey;
  size?: number;
  color?: TextColor;
  iconSx?: React.CSSProperties;
  className?: string;
}

export const Icon = ({
  iconName: name,
  size = 24,
  color,
  iconSx: sx = {},
  className = "",
}: IIconProps) => {
  const iconClassName = IconMap[name];
  const iconColor = color ? `text-${color}` : "";
  let iconSize = "fs-24";

  if (size !== undefined && size > 0) {
    if (size >= 9 && size <= 30) {
      iconSize = `fs-${size}`;
    } else {
      sx.fontSize = `${size}px`;
    }
  }

  return (
    <i
      className={`${iconClassName} ${iconSize} ${iconColor} ${className}`}
      style={sx}
    />
  );
};

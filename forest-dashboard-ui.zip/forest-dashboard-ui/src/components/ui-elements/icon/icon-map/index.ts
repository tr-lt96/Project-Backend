import {
  FontAwesomeIconKey,
  FontAwesomeIconMap,
} from "./icon-font-awesome-map";
import { IcofontIconKey, IcofontIconMap } from "./icon-icofont-map";
import { IconoirIconKey, IconoirIconMap } from "./icon-iconoir-map";
import {
  LineAwesomeIconKey,
  LineAwesomeIconMap,
} from "./icon-line-awesome-map";

export const IconMap = {
  ...FontAwesomeIconMap,
  ...LineAwesomeIconMap,
  ...IcofontIconMap,
  ...IconoirIconMap,
};

export type IconKey =
  | FontAwesomeIconKey
  | LineAwesomeIconKey
  | IcofontIconKey
  | IconoirIconKey;

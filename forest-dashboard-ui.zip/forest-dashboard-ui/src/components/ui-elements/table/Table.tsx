import { useMemo } from "react";
import { Table as BsTable, TableProps as BsTableProps } from "react-bootstrap";
import { capitalized } from "../../../functions/data/transformers";

interface ITableProps<T extends Record<string, unknown>> extends BsTableProps {
  headers?: (string | JSX.Element)[];
  items: T[];
  id: string;
}

export function Table<T extends Record<string, unknown>>({
  items,
  headers,
  id: tableId,
  ...props
}: ITableProps<T>) {
  const tableHeaders = useMemo(
    () =>
      headers ||
      Object.keys(items).map((header) => {
        return capitalized(header);
      }),
    []
  );

  const TableHeaders = () => {
    return (
      <thead className="table-light">
        <tr>
          {tableHeaders.map((header, index) => {
            const key = `${tableId}-thead-tr-th-${index}`;
            return <th key={key}>{header}</th>;
          })}
        </tr>
      </thead>
    );
  };

  const TableItem = ({ item, index }: { item: T; index: number }) => {
    const itemArray = Object.keys(item).map(
      (field) => item[field]
    ) as React.ReactNode[];

    return (
      <tr>
        {itemArray.map((field, fieldIndex) => {
          const key = `${tableId}-tbody-tr-td-${index}-${fieldIndex}`;
          return <td key={key}>{field}</td>;
        })}
      </tr>
    );
  };

  const TableRows = () => {
    return (
      <tbody>
        {items.map((item, index) => {
          const key = `${tableId}-tbody-tr-${index}`;
          return <TableItem key={key} item={item} index={index} />;
        })}
      </tbody>
    );
  };

  return (
    <BsTable {...props}>
      <TableHeaders />
      <TableRows />
    </BsTable>
  );
}

import { Button as BsButton } from "react-bootstrap";
import { BasicColor } from "../color";

type IButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  color?: BasicColor;
  variant?: "solid" | "outlined" | "soft";
  children: React.ReactNode;
};

export const Button = ({
  color = "primary",
  className = "",
  variant = "soft",
  children,
  ...buttonProps
}: IButtonProps) => {
  const buttonStyleVariant =
    variant === "outlined" ? "outline" : variant === "soft" ? "soft" : "";

  const buttonVariant = buttonStyleVariant
    ? `${buttonStyleVariant}-${color}`
    : color;

  const borderStyle = variant === "outlined" ? "" : "border-0";

  return (
    <BsButton
      {...buttonProps}
      variant={buttonVariant}
      className={`p-2 lh-0 ${borderStyle} ${className}`}
    >
      {children}
    </BsButton>
  );
};

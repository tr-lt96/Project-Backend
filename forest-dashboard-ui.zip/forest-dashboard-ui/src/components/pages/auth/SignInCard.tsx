import { SignInForm } from "./SignInForm";
import { SocialAuthSection } from "./SocialAuthSection";
import { useAuthPageContext } from "../../contexts/page";
import { AuthCard } from "./AuthCard";

const SignUpSuggestion = () => {
  const { toSignUpPage } = useAuthPageContext();

  return (
    <div className="text-center mb-2">
      <p className="text-muted">
        Don't have an account ?{" "}
        <span
          role="button"
          className="text-primary ms-2"
          onClick={toSignUpPage}
        >
          Free Resister
        </span>
      </p>
    </div>
  );
};

export const SignInCard = () => {
  return (
    <AuthCard title={"Let's Get Started"} subTitle={"Sign in to continue."}>
      <SignInForm />
      <SignUpSuggestion />
      <SocialAuthSection />
    </AuthCard>
  );
};

import { useNavigate } from "react-router-dom";
import { AuthCard } from "./AuthCard";
import { ForgotPasswordForm } from "./ForgotPasswordForm";
import { RoutePathname } from "../../../utils/router";

const SignInSuggestion = () => {
  const navigate = useNavigate();
  const toSignInPage = () => navigate(RoutePathname.auth);

  return (
    <div className="text-center mb-2">
      <p className="text-muted">
        Remember it ?{" "}
        <span
          role="button"
          className="text-primary ms-2"
          onClick={toSignInPage}
        >
          Login here
        </span>
      </p>
    </div>
  );
};

export const ForgotPasswordCard = () => {
  return (
    <AuthCard
      title={"Forgot your password ?"}
      subTitle={"Enter your email and instructions will be sent to you!"}
    >
      <ForgotPasswordForm />
      <SignInSuggestion />
    </AuthCard>
  );
};

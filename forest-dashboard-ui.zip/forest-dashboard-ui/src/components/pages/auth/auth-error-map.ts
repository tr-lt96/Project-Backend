import { TAuthState } from "../../contexts/page";

export const AuthErrors: Record<TAuthState, Record<string, string>> = {
  signin: {
    "auth/too-many-requests": "Too many requests, please try again later.",
    "auth/invalid-credential":
      "Incorrect email or password. Please check your credentials.",
    default: "Error while logging in.",
  },
  signup: {
    "auth/email-already-in-use": "Email is already in use/registered.",
    "auth/too-many-requests": "Too many requests, please try again later.",
    default: "Error while creating account, please try again later.",
  },
};

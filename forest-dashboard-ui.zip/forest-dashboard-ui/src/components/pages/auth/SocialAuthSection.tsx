import { useNavigate } from "react-router-dom";
import { authFn } from "../../../functions/account/auth";
import { useAuthContext } from "../../contexts/account";
import { IconButton } from "../../ui-elements";
import { RoutePathname } from "../../../utils/router";
import { useAuthPageContext } from "../../contexts/page";

export const SocialAuthSection = () => {
  const { googleSignin } = authFn;
  const { initUser } = useAuthContext();
  const { setAuthError } = useAuthPageContext();
  const navigate = useNavigate();

  const onClickGoogleBtn = () => {
    googleSignin()
      .then(({ user }) => {
        if (user?.uid) {
          initUser(user);
          navigate(RoutePathname.dashboard);
        } else {
          setAuthError("Unable to authenticate via Google.");
        }
      })
      .catch((error) => {
        console.error(error);
        setAuthError("Unable to authenticate via Google.");
      });
  };

  return (
    <div className="d-flex justify-content-center align-items-center px-3">
      <h6 className="mb-0">Or Login With</h6>
      <IconButton
        onClick={onClickGoogleBtn}
        iconName="FaGoogle"
        color="danger"
        variant="soft"
        className="rounded-circle ms-1"
        size={18}
      />
    </div>
  );
};

import { Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { formValidator } from "../../../functions/form/validators";
import { FormError, Icon, Button } from "../../ui-elements";
import { authFn } from "../../../functions/account/auth";
import { Alert } from "../../ui-elements/alert/Alert";
import { useState } from "react";

interface IForgotPasswordFormValues {
  email: string;
}

export const ForgotPasswordForm = () => {
  const [sendEmailSuccess, setSendEmailSuccess] = useState<boolean | null>(
    null
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IForgotPasswordFormValues>({
    defaultValues: {
      email: "",
    },
  });

  const emailFormProps = register("email", {
    ...formValidator.required,
    ...formValidator.email,
  });

  const onSubmitForm: SubmitHandler<IForgotPasswordFormValues> = (
    formValues
  ) => {
    authFn
      .sendResetPassword(formValues.email)
      .then(() => {
        setSendEmailSuccess(true);
      })
      .catch((error) => {
        console.error(error);
        setSendEmailSuccess(false);
      });
  };

  const AuthErrorAlert = () => {
    if (sendEmailSuccess === null) {
      return null;
    }

    if (sendEmailSuccess === true) {
      return (
        <Alert
          level="success"
          message={"Reset password email sent! Please check your inbox."}
        />
      );
    }

    return (
      <Alert
        level="danger"
        message={"Issue while sending reset password email."}
      />
    );
  };

  return (
    <Form className="my-4" onSubmit={handleSubmit(onSubmitForm)}>
      <AuthErrorAlert />

      {sendEmailSuccess !== true && (
        <>
          <Form.Group className="mb-3" controlId="email">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter email"
              isInvalid={!!errors.email}
              {...emailFormProps}
            />
            <FormError error={errors.email} />
          </Form.Group>

          <Form.Group className="mb-0 row">
            <div className="col-12">
              <div className="d-grid">
                <Button
                  color="primary"
                  variant="solid"
                  type="submit"
                  className="d-flex align-items-center justify-content-center"
                >
                  Reset password
                  <Icon iconName={"FaSignInAlt"} size={16} className="ms-1" />
                </Button>
              </div>
            </div>
          </Form.Group>
        </>
      )}
    </Form>
  );
};

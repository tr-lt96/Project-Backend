import { Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { formValidator } from "../../../functions/form/validators";
import { FormError, Icon, Button } from "../../ui-elements";
import { authFn } from "../../../functions/account/auth";
import { Link, useNavigate } from "react-router-dom";
import { RoutePathname } from "../../../utils/router";
import { useAuthContext } from "../../contexts/account";
import { Alert } from "../../ui-elements/alert/Alert";
import { useAuthPageContext } from "../../contexts/page";
import { AuthErrors } from "./auth-error-map";

interface ISignInFormValues {
  email: string;
  password: string;
}

export const SignInForm = () => {
  const navigate = useNavigate();
  const { initUser } = useAuthContext();
  const { authError, setAuthError } = useAuthPageContext();
  const errorMessages = AuthErrors.signin;

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ISignInFormValues>({
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const emailFormProps = register("email", {
    ...formValidator.required,
    ...formValidator.email,
  });

  const passwordFormProps = register("password", {
    ...formValidator.required,
  });

  const onSubmitForm: SubmitHandler<ISignInFormValues> = (formValues) => {
    authFn
      .login(formValues.email, formValues.password)
      .then(({ user }) => {
        if (user?.uid) {
          initUser(user);
          navigate(RoutePathname.dashboard);
        } else {
          setAuthError(errorMessages.default);
        }
      })
      .catch((error) => {
        console.error(error);
        setAuthError(errorMessages[error?.code] || errorMessages.default);
      });
  };

  const AuthErrorAlert = () => {
    if (!authError) {
      return null;
    }

    return <Alert level="danger" message={authError} />;
  };

  return (
    <Form className="my-4" onSubmit={handleSubmit(onSubmitForm)}>
      <AuthErrorAlert />

      <Form.Group className="mb-2" controlId="email">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter email"
          isInvalid={!!errors.email}
          {...emailFormProps}
        />
        <FormError error={errors.email} />
      </Form.Group>

      <Form.Group className="mb-3" controlId="password">
        <Form.Label>Password</Form.Label>
        <Form.Control
          type="password"
          placeholder="Enter password"
          isInvalid={!!errors.password}
          {...passwordFormProps}
        />
        <FormError error={errors.password} />
      </Form.Group>

      <Form.Group className="mb-3">
        <div className="col-12">
          <Link
            to={RoutePathname.forgotPassword}
            className="text-muted font-13 text-start"
          >
            Forgot password?
          </Link>
        </div>
      </Form.Group>

      <Form.Group className="mb-0 row">
        <div className="col-12">
          <div className="d-grid">
            <Button
              color="primary"
              variant="solid"
              type="submit"
              className="d-flex align-items-center justify-content-center"
            >
              Log In
              <Icon iconName={"FaSignInAlt"} size={16} className="ms-1" />
            </Button>
          </div>
        </div>
      </Form.Group>
    </Form>
  );
};

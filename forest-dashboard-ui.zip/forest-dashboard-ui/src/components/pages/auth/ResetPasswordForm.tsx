import { Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { formValidator } from "../../../functions/form/validators";
import { FormError, Icon, Button } from "../../ui-elements";
import { authFn } from "../../../functions/account/auth";
import { Alert } from "../../ui-elements/alert/Alert";
import { useState } from "react";

interface IResetPasswordFormValues {
  password: string;
  confirmPassword: string;
}

export const ResetPasswordForm = ({ code }: { code: string }) => {
  const [resetSuccess, setResetSuccess] = useState<boolean | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm<IResetPasswordFormValues>({
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });

  const passwordFormProps = register("password", {
    ...formValidator.required,
    ...formValidator.password,
  });

  const confirmPasswordFormProps = register("confirmPassword", {
    ...formValidator.required,
  });

  const onSubmitForm: SubmitHandler<IResetPasswordFormValues> = (
    formValues
  ) => {
    if (formValues.password !== formValues.confirmPassword) {
      setError("confirmPassword", {
        message: "Does not match the above password.",
      });
      return;
    }

    authFn
      .resetPassword(code, formValues.password)
      .then(() => {
        setResetSuccess(true);
      })
      .catch((error) => {
        console.error(error);
        setResetSuccess(false);
      });
  };

  const AuthErrorAlert = () => {
    if (resetSuccess === null) {
      return null;
    }

    if (resetSuccess === true) {
      return <Alert level="success" message={"Password have been reset!"} />;
    }

    return (
      <Alert
        level="danger"
        message={"Issue while resetting password, please try again."}
      />
    );
  };

  return (
    <Form className="my-4" onSubmit={handleSubmit(onSubmitForm)}>
      <AuthErrorAlert />

      {resetSuccess !== true && (
        <>
          <Form.Group className="mb-2" controlId="password">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Enter password"
              isInvalid={!!errors.password}
              {...passwordFormProps}
            />
            <FormError error={errors.password} />
          </Form.Group>

          <Form.Group className="mb-3" controlId="confirm-password">
            <Form.Label>Confirm Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Confirm your password"
              isInvalid={!!errors.confirmPassword}
              {...confirmPasswordFormProps}
            />
            <FormError error={errors.confirmPassword} />
          </Form.Group>

          <Form.Group className="mb-0 row">
            <div className="col-12">
              <div className="d-grid">
                <Button
                  color="primary"
                  variant="solid"
                  type="submit"
                  className="d-flex align-items-center justify-content-center"
                >
                  Reset password
                  <Icon iconName={"FaSignInAlt"} size={16} className="ms-1" />
                </Button>
              </div>
            </div>
          </Form.Group>
        </>
      )}
    </Form>
  );
};

import { Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { formValidator } from "../../../functions/form/validators";
import { FormError, Icon, Button } from "../../ui-elements";
import { authFn } from "../../../functions/account/auth";
import { useNavigate } from "react-router-dom";
import { RoutePathname } from "../../../utils/router";
import { useAuthContext } from "../../contexts/account";
import { Alert } from "../../ui-elements/alert/Alert";
import { AuthErrors } from "./auth-error-map";
import { useAuthPageContext } from "../../contexts/page";

interface ISignUpFormValues {
  email: string;
  password: string;
  confirmPassword: string;
}

export const SignUpForm = () => {
  const navigate = useNavigate();
  const { initUser } = useAuthContext();
  const { authError, setAuthError } = useAuthPageContext();
  const errorMessages = AuthErrors.signup;

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm<ISignUpFormValues>({
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const emailFormProps = register("email", {
    ...formValidator.required,
    ...formValidator.email,
  });

  const passwordFormProps = register("password", {
    ...formValidator.required,
    ...formValidator.password,
  });

  const confirmPasswordFormProps = register("confirmPassword", {
    ...formValidator.required,
  });

  const submitForm: SubmitHandler<ISignUpFormValues> = (formValues) => {
    if (formValues.password !== formValues.confirmPassword) {
      setError("confirmPassword", {
        message: "Does not match the above password.",
      });
      return;
    }

    authFn
      .signup(formValues.email, formValues.password)
      .then(({ user }) => {
        if (user?.uid) {
          initUser(user);
          navigate(RoutePathname.dashboard);
        } else {
          setAuthError(errorMessages.default);
        }
      })
      .catch((error) => {
        console.log(`${error.code}`);
        console.log(errorMessages[error?.code]);
        setAuthError(errorMessages[error?.code] || errorMessages.default);
      });
  };

  const AuthErrorAlert = () => {
    if (!authError) {
      return null;
    }

    return <Alert level="danger" message={authError} />;
  };

  return (
    <Form className="my-4" onSubmit={handleSubmit(submitForm)}>
      <AuthErrorAlert />

      <Form.Group className="mb-2" controlId="email">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter email"
          isInvalid={!!errors.email}
          {...emailFormProps}
        />
        <FormError error={errors.email} />
      </Form.Group>

      <Form.Group className="mb-2" controlId="password">
        <Form.Label>Password</Form.Label>
        <Form.Control
          type="password"
          placeholder="Enter password"
          isInvalid={!!errors.password}
          {...passwordFormProps}
        />
        <FormError error={errors.password} />
      </Form.Group>

      <Form.Group className="mb-2" controlId="confirm-password">
        <Form.Label>Confirm Password</Form.Label>
        <Form.Control
          type="password"
          placeholder="Confirm your password"
          isInvalid={!!errors.confirmPassword}
          {...confirmPasswordFormProps}
        />
        <FormError error={errors.confirmPassword} />
      </Form.Group>

      <Form.Group className="mb-0 row">
        <div className="col-12">
          <div className="d-grid mt-3">
            <Button
              color="primary"
              variant="solid"
              type="submit"
              className="d-flex align-items-center justify-content-center"
            >
              Create new account
              <Icon iconName={"FaSignInAlt"} size={16} className="ms-1" />
            </Button>
          </div>
        </div>
      </Form.Group>
    </Form>
  );
};

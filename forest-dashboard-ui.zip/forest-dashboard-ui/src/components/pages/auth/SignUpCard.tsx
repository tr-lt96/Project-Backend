import { SignUpForm } from "./SignUpForm";
import { SocialAuthSection } from "./SocialAuthSection";
import { useAuthPageContext } from "../../contexts/page";
import { AuthCard } from "./AuthCard";

const SignInSuggestion = () => {
  const { toSignInPage } = useAuthPageContext();

  return (
    <div className="text-center mb-2">
      <p className="text-muted">
        Already have an account ?{" "}
        <span
          role="button"
          className="text-primary ms-2"
          onClick={toSignInPage}
        >
          Login
        </span>
      </p>
    </div>
  );
};

export const SignUpCard = () => {
  return (
    <AuthCard title={"Create an account"} subTitle={"Register to continue."}>
      <SignUpForm />
      <SignInSuggestion />
      <SocialAuthSection />
    </AuthCard>
  );
};

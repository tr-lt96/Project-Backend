import { Card } from "react-bootstrap";

interface IAuthCardHeaderProps {
  title: string;
  subTitle?: string;
}

const AuthCardHeader = ({ title, subTitle }: IAuthCardHeaderProps) => {
  return (
    <Card.Body className="p-0 bg-black auth-header-box rounded-top">
      <div className="text-center p-3">
        <h4 className="mt-3 mb-1 fw-semibold text-white fs-18">{title}</h4>

        {subTitle ? (
          <p className="text-muted fw-medium mb-0">{subTitle}</p>
        ) : null}
      </div>
    </Card.Body>
  );
};

interface IAuthCardProps {
  title: string;
  subTitle?: string;
  children: React.ReactNode;
}

export const AuthCard = ({ children, title, subTitle }: IAuthCardProps) => {
  return (
    <Card>
      <AuthCardHeader title={title} subTitle={subTitle} />
      <Card.Body className="pt-0">{children}</Card.Body>
    </Card>
  );
};

import { AuthCard } from "./AuthCard";
import { useNavigate, useSearchParams } from "react-router-dom";
import { PageLayoutBase } from "../../ui-universal/page-layout/PageLayoutBase";
import { ResetPasswordForm } from "./ResetPasswordForm";
import { RoutePathname } from "../../../utils/router";

const SignInSuggestion = () => {
  const navigate = useNavigate();
  const toSignInPage = () => navigate(RoutePathname.auth);

  return (
    <div className="text-center mb-2">
      <p className="text-muted">
        Back to{" "}
        <span role="button" className="text-primary" onClick={toSignInPage}>
          login page
        </span>
      </p>
    </div>
  );
};

export const ResetPasswordCard = () => {
  const [params] = useSearchParams();
  const resetOobCode = params.get("oobCode");
  if (!resetOobCode) {
    return (
      <PageLayoutBase>
        <div className="text-center">
          <p>Require email reset code</p>
        </div>
      </PageLayoutBase>
    );
  }

  return (
    <AuthCard
      title={"Reset your password"}
      subTitle={"Choose a new password for your account."}
    >
      <ResetPasswordForm code={resetOobCode} />
      <SignInSuggestion />
    </AuthCard>
  );
};

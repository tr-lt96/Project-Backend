import { createContext, useContext } from "react";

export type TAuthState = "signin" | "signup";

interface IAuthPageContext {
  authState: TAuthState;
  toSignInPage: () => void;
  toSignUpPage: () => void;
  authError?: string;
  setAuthError: (error: string) => void;
}

export const AuthPageContext = createContext<IAuthPageContext>({
  authState: "signin",
  toSignInPage: () => {},
  toSignUpPage: () => {},
  authError: undefined,
  setAuthError: () => {},
});

export const useAuthPageContext = () => useContext(AuthPageContext);

import { useState } from "react";
import { AuthPageContext, TAuthState } from "./AuthPageContext";

export const AuthPageProvider = ({
  children,
  initAuthState,
}: {
  children: React.ReactNode;
  initAuthState: TAuthState;
}) => {
  const [authState, setAuthState] = useState<TAuthState>(initAuthState);
  const [authError, setAuthError] = useState<string>();

  const toSignInPage = () => {
    setAuthState("signin");
  };

  const toSignUpPage = () => {
    setAuthState("signup");
  };

  return (
    <AuthPageContext.Provider
      value={{ authState, toSignInPage, toSignUpPage, authError, setAuthError }}
    >
      {children}
    </AuthPageContext.Provider>
  );
};

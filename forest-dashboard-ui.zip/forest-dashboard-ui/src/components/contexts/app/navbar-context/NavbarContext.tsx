import { createContext, useContext } from "react";

export type NavbarMetaValue = "default" | "collapsed";

interface INavbarContext {
  metaValue: NavbarMetaValue;
  closeSidebar: () => void;
  toggleSidebar: () => void;
}

export const NavbarContext = createContext<INavbarContext>({
  metaValue: "collapsed",
  closeSidebar: () => {},
  toggleSidebar: () => {},
});

export const useNavbarContext = () => useContext(NavbarContext);

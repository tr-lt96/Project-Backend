import { useState } from "react";
import { NavbarContext, NavbarMetaValue } from "./NavbarContext";

export const NavbarProvider = ({ children }: { children: React.ReactNode }) => {
  const [sidebarMeta, setSidebarMeta] = useState<NavbarMetaValue>("collapsed");

  const toggleSidebar = () => {
    setSidebarMeta(sidebarMeta === "default" ? "collapsed" : "default");
  };
  const closeSidebar = () => setSidebarMeta("collapsed");

  return (
    <NavbarContext.Provider
      value={{
        metaValue: sidebarMeta,
        toggleSidebar,
        closeSidebar,
      }}
    >
      {children}
    </NavbarContext.Provider>
  );
};

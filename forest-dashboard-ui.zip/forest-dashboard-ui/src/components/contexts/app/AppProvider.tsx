import { AccountProvider } from "../account";
import { NavbarProvider } from "./navbar-context/NavbarProvider";
import { ThemeProvider } from "./theme-context/ThemeProvider";

export const AppProvider = ({ children }: { children: React.ReactNode }) => {
  return (
    <AccountProvider>
      <ThemeProvider>
        <NavbarProvider>{children}</NavbarProvider>
      </ThemeProvider>
    </AccountProvider>
  );
};

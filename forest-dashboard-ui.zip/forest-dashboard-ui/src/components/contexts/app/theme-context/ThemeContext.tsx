import { createContext, useContext } from "react";

export type BsTheme = "light" | "dark";

interface IThemeContext {
  theme: BsTheme;
  toggleTheme: () => void;
}

export const ThemeContext = createContext<IThemeContext>({
  theme: "light",
  toggleTheme: () => {},
});

export const useThemeContext = () => useContext(ThemeContext);

import { useState } from "react";
import { BsTheme, ThemeContext } from "./ThemeContext";

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const storedTheme: BsTheme =
    window.localStorage.getItem("theme-preferrence") === "light"
      ? "light"
      : "dark";

  const [theme, setTheme] = useState<BsTheme>(storedTheme);

  const toggleTheme = () => {
    const value = theme === "light" ? "dark" : "light";
    setTheme(value);
    window.localStorage.setItem("theme-preferrence", value);
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

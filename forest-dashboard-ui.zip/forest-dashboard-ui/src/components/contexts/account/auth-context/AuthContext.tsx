import { User } from "firebase/auth";
import { createContext, useContext } from "react";

interface IAuthContext {
  user: AuthUser | null;
  isValidatingUser: boolean;
  initUser: (userData: AuthUser) => void;
  unsetUser: () => void;
}

export type AuthUser = User;

export const AuthContext = createContext<IAuthContext>({
  user: null,
  isValidatingUser: true,
  initUser: () => {},
  unsetUser: () => {},
});

export const useAuthContext = () => useContext(AuthContext);

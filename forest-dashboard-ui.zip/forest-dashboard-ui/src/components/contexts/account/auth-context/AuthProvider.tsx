import { useEffect, useState } from "react";
import { AuthContext, AuthUser } from "./AuthContext";
import { appAuth } from "../../../../firebase";
import { onAuthStateChanged } from "firebase/auth";

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isValidating, setValidating] = useState<boolean>(true);

  const initUser = (user: AuthUser) => {
    setUser(user);
  };

  const unsetUser = () => {
    setUser(null);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(appAuth, (user) => {
      if (user) {
        setUser(user);
      } else {
        setUser(null);
      }
      setValidating(false);
    });

    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isValidatingUser: isValidating,
        initUser,
        unsetUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

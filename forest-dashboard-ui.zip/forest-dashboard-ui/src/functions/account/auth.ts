import {
  confirmPasswordReset,
  createUserWithEmailAndPassword,
  getIdToken,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  UserCredential,
  verifyPasswordResetCode,
} from "firebase/auth";
import { appAuth } from "../../firebase";

function signup(email: string, password: string): Promise<UserCredential> {
  return createUserWithEmailAndPassword(appAuth, email, password);
}

function googleSignin(): Promise<UserCredential> {
  const provider = new GoogleAuthProvider();
  return signInWithPopup(appAuth, provider);
}

function login(email: string, password: string): Promise<UserCredential> {
  return signInWithEmailAndPassword(appAuth, email, password);
}

function sendResetPassword(email: string): Promise<void> {
  return sendPasswordResetEmail(appAuth, email);
}

function verifyResetCode(code: string) {
  return verifyPasswordResetCode(appAuth, code);
}

function resetPassword(oobCode: string, newPassword: string) {
  return confirmPasswordReset(appAuth, oobCode, newPassword);
}

function logout(): Promise<void> {
  return signOut(appAuth);
}

export const authFn = {
  signup,
  login,
  logout,
  googleSignin,
  getToken: getIdToken,
  sendResetPassword,
  verifyResetCode,
  resetPassword,
};

/**
 * https://github.com/jonschlinkert/is-number/blob/master/index.js
 * Validate if a number string is a valid number
 * @param {string | number} num - String number (i.e. '10', '5.6' or '-1') or actual number
 */
const isValidNumber = (num: string | number) => {
  const typeOfNum = typeof num;
  if (typeOfNum === "number") {
    return num === 0;
  }
  if (typeOfNum === "string" && (num as string).trim() !== "") {
    return Number.isFinite ? Number.isFinite(+num) : isFinite(+num);
  }
  return false;
};

/**
 * Validate if date string is valid
 * @param {string} date - Date input
 */
const isValidDate = (date: string) => {
  const dateObj = new Date(date);

  if (isNaN(dateObj.getTime())) {
    return false;
  }

  return true;
};

export const dataValidator = {
  number: isValidNumber,
  date: isValidDate,
};

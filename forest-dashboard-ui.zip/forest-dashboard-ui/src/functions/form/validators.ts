import { ValidationRule } from "react-hook-form";

// type Validator = RegisterOptions<FieldValues, string>

// Required validator
// ====================================================
const requiredValidator = {
  required: {
    value: true,
    message: "This field is required",
  } as ValidationRule<boolean>,
};

// Email validator
// ====================================================

const EmailRegexp =
  // eslint-disable-next-line no-useless-escape
  /^\w+([\.-]?\w+)+@\w+([-]?\w+)\.([a-z]+)(\.[a-z]+)?$/;
/**
 * https://github.com/Enggawadhesh/Regex-Validation/blob/master/use-js-regex-validation.js
 * Validator for email
 */
const emailValidator = {
  pattern: {
    value: EmailRegexp,
    message: "Invalid email format.",
  },
};

// Password validator
// ====================================================
const PasswordNumber = Array.from("0123456789");
const PasswordSpecialCharacters = Array.from(
  "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
);
const PasswordCapitalCharacter = Array.from(
  "abcdefghijklmnopqrstuvwxyz".toUpperCase()
);

/**
 * Validator for password
 */
const passwordValidator = {
  validate: {
    mustHaveNumber: (pw: string) => {
      const hasNumber = PasswordNumber.some((num) => pw.includes(num));
      return hasNumber || "Must include a number.";
    },
    mustHaveSpecialChar: (pw: string) => {
      const hasSpecialChar = PasswordSpecialCharacters.some((char) =>
        pw.includes(char)
      );
      return (
        hasSpecialChar || "Must include a special character (i.e. @, -, $)."
      );
    },
    mustHaveCapitalChar: (pw: string) => {
      const hasCapitalChar = PasswordCapitalCharacter.some((char) =>
        pw.includes(char)
      );
      return hasCapitalChar || "Must include a capitallised character.";
    },
  },
};

// Phone validator
// ====================================================
const PhoneRegexp = /^(\+61|0)[23478]\d{8}$/;
/**
 * Validate if phone number is valid
 * @param {string} phoneNumber - Phone number input
 */
const phoneValidator = {
  pattern: {
    value: PhoneRegexp,
    message: "Invalid phone number.",
  },
};

// Address number validator
// ====================================================
// eslint-disable-next-line no-useless-escape
const AddressNumberRegExp = /^[\w\d]+([\/-]?[\w\d]+)*/;
/**
 * Validate if address number is valid
 * @param {string} addressNo - Address number input
 */
const addressNoValidator = {
  pattern: {
    value: AddressNumberRegExp,
    message: "Invalid address number format.",
  },
};

export const formValidator = {
  email: emailValidator,
  phone: phoneValidator,
  addressNo: addressNoValidator,
  password: passwordValidator,
  required: requiredValidator,
};

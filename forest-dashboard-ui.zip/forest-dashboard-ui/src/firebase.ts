// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// https://firebase.google.com/docs/web/setup#available-libraries

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA5tO-wBZuv8aU4MWmTFLQIaDqLtc8O7Bk",
  authDomain: "galleon-starter.firebaseapp.com",
  projectId: "galleon-starter",
  storageBucket: "galleon-starter.firebasestorage.app",
  messagingSenderId: "786508844737",
  appId: "1:786508844737:web:17e71cf338388b644a4e40",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const appAuth = getAuth(app);
export default app;

interface IUser {
  id: string;
  email: string;

  firstName?: string;
  lastName?: string;
  address?: IUserAddress;
  phone?: string;
}

interface IUserAddress {
  unitNo?: number;
  streetNo: number;
  streetName: string;
  city: string;
  state: StateCode;
  postcode: string;
}

type StateCode = "ACT" | "NSW" | "NT" | "QLD" | "SA" | "TAS" | "VIC" | "WA";

interface IUserSession {
  id: string;
  token: string;
}

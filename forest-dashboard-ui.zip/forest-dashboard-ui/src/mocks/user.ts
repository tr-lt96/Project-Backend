import { mockMatchPassword } from "./security";

const KEY_TO_SECRET_CHAMBER = "MTIzYWJjMTJA";

const MOCK_USER_SESSION_DATA = [
  {
    id: "user-1",
    token: "ZXhhbXBsZTFAZXhhbXBsZS5jb206MTIzYWJjMTJA",
    expiry: 1821531612251,
  },
];

const MOCK_USER_DATAS = [
  {
    id: "user-1",
    email: "example1@example.com",
  },
  {
    id: "user-2",
    email: "example2@example.com",
  },
];

export const mockRetrieveUserSession = async (request: {
  userId: string;
  token: string;
}) => {
  const matchData = MOCK_USER_SESSION_DATA.find(
    (record) => record.id === request.userId
  );

  if (!matchData || matchData.token !== request.token) {
    return null;
  }

  const currentTime = Date.now();
  if (matchData.expiry < currentTime) {
    return null;
  }

  return MOCK_USER_DATAS.find((user) => user.id === request.userId);
};

export const mockUserLogin = async (request: {
  email: string;
  password: string;
}) => {
  const { email, password } = request;

  if (!MOCK_USER_DATAS.find((user) => user.email === email)) {
    return null;
  }

  // Validate password and compare to stored password hash
  if (!mockMatchPassword(password, KEY_TO_SECRET_CHAMBER)) {
    return null;
  }

  const user = MOCK_USER_DATAS.find((user) => user.email === email) as IUser;

  const tokenHash = btoa(`${email}:${password}`);
  const sessionJSONstring = JSON.stringify({
    id: user.id,
    token: tokenHash,
  });

  window.localStorage.setItem("user-session", btoa(sessionJSONstring));

  return user;
};

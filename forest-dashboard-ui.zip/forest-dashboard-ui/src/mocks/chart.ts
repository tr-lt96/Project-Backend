import { TApexChartBaseProps } from "../components/ui-elements/chart/chart-type";

export const mockExpenseBarChart = {
  data: [
    {
      name: "Income",
      data: [2.7, 2.2, 1.3, 2.5, 1, 2.5, 1.2, 1.2, 2.7, 1, 3.6, 2.1],
    },
    {
      name: "Expense",
      data: [
        -2.3, -1.9, -1, -2.1, -1.3, -2.2, -1.1, -2.3, -2.8, -1.1, -2.5, -1.5,
      ],
    },
  ],
  options: {
    chart: {
      foreColor: "#adb0bb",
      height: 370,
      stacked: true,
      offsetX: -15,
    },
    colors: ["var(--bs-success)", "rgba(155, 171, 187, .25)"],
    plotOptions: {
      bar: {
        horizontal: false,
        barHeight: "80%",
        columnWidth: "20%",
        borderRadius: 3,
      },
    },
    legend: {
      show: false,
    },
    xaxis: {
      axisBorder: {
        show: false,
      },
      axisTicks: {
        show: false,
      },
      categories: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "July",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ],
    },
    yaxis: {
      tickAApprox: 4,
      labels: {
        show: true,
        formatter: function (val: never) {
          return "$" + val + "k";
        },
      },
    },
  } as TApexChartBaseProps<"bar">["options"],
};

export const mockDonutChart = {
  data: [50, 25, 10, 15],
  options: {
    chart: {
      height: 280,
      type: "donut",
    },
    plotOptions: {
      pie: {
        donut: {
          size: "80%",
        },
      },
    },
    dataLabels: {
      enabled: true,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ["transparent"],
    },

    legend: {
      show: true,
      position: "bottom",
      horizontalAlign: "center",
      verticalAlign: "middle",
      floating: false,
      fontSize: "13px",
      fontFamily: "Be Vietnam Pro, sans-serif",
      offsetX: 0,
      offsetY: 0,
    },
    labels: ["USD", "Euro", "Pounds", "Dinar"],
    colors: ["#0e2a89", "#d96345", "#ffb600", "#47cdea"],

    responsive: [
      {
        breakpoint: 600,
        options: {
          plotOptions: {
            donut: {
              customScale: 0.2,
            },
          },
          chart: {
            height: 240,
          },
          legend: {
            show: false,
          },
        },
      },
    ],
    tooltip: {
      y: {
        formatter: function (val: never) {
          return val + " %";
        },
      },
    },
  } as TApexChartBaseProps<"pie">["options"],
};

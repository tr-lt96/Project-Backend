export const RoutePathname = {
  app: "/",
  dashboard: "/dashboard",
  auth: "/auth",
  forgotPassword: "/forgot-password",
  resetPassword: "/reset-password",
  docs: "/docs",
};

export const ValidPathSegments = Object.keys(RoutePathname);

import {
  createBrowserRouter,
  Route,
  RouterProvider,
  Routes,
} from "react-router-dom";
import {
  useNavbarContext,
  useThemeContext,
} from "../../components/contexts/app";
import DashboardPage from "../../pages/DashboardPage";
import HomePage from "../../pages/HomePage";
import { AuthPage } from "../../pages/auth/AuthPage";
import { RoutePathname } from "./route-map";
import { ForgotPasswordPage } from "../../pages/auth/ForgotPasswordPage";
import { ResetPasswordPage } from "../../pages/auth/ResetPasswordPage";
import { PageError } from "../../components/ui-universal";
import { ErrorCodes } from "../error";
import { DocsRouter } from "../../docs/router/DocsRouter";

const RootElement = () => {
  const { theme } = useThemeContext();
  const { metaValue: sidebarMeta } = useNavbarContext();

  return (
    <main
      id="app-content"
      data-bs-theme={theme}
      data-sidebar-size={sidebarMeta}
    >
      <Routes>
        {/** Edit the below section to add or remove page*/}
        {/** ---- BEGIN ------*/}
        <Route path="/" element={<HomePage />} />
        <Route path={RoutePathname.dashboard} element={<DashboardPage />} />
        <Route path={RoutePathname.auth} element={<AuthPage />} />
        <Route
          path={RoutePathname.forgotPassword}
          element={<ForgotPasswordPage />}
        />
        <Route
          path={RoutePathname.resetPassword}
          element={<ResetPasswordPage />}
        />
        <Route path={`${RoutePathname.docs}/*`} element={<DocsRouter />} />
        <Route
          path="*"
          element={<PageError code={404} message={ErrorCodes[400]} />}
        />
        {/** ---- END ------*/}
      </Routes>
    </main>
  );
};

const router = createBrowserRouter([{ path: "*", element: <RootElement /> }]);

export const AppRouter = () => {
  return <RouterProvider router={router}></RouterProvider>;
};

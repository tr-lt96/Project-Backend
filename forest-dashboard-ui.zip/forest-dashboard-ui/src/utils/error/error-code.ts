export const ErrorCodes: Record<number, string> = {
  400: "Oops! Page not found",
  500: "Sorry! Unexpected Server Error",
};

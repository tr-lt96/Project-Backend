import "./assets/css/bootstrap.css";
import "./assets/css/app.css";
import "./assets/css/icons.css";
import { AppProvider } from "./components/contexts/app";
import { AppRouter } from "./utils/router";

function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}

export default App;

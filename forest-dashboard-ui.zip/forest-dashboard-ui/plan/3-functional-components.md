- dashboard components

- Get started
  - Installation

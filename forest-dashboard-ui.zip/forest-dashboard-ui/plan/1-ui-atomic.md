# About UI Elements - atomic (ui-elements)

This package will consist the most basic building blocks of the components. This will include but not limited to:

- All react-bootstrap basic components
  - button
  - card
  - form elements
    - input
    - dropdown
  - grid
  - badge
- Custom components
  - icon

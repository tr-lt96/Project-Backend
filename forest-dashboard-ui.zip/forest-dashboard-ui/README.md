# About forest dashboard UI

This repository is an attempt to create a react app from `approx-v1.0` template, with modularised components and documentations to make it easier for developer to familiarise and build web app with the code base.

# Get started

To get started, you need to install the following:

- `node` version >=20
- `npm` version >=10

## Way to install `node` and `npm`

- Install Using `nvm`:

  - Download and install nvm:

  ```bash

  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
  ```

  - Download and install Node.js:

  ```bash

  nvm install 20

  ```

- Install Using `Homebrew`:

  - Download and install Homebrew:

  ```bash

  curl -o- https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh | bash

  ```

  - Download and install Node.js:

  ```bash

  brew install node@20

  ```

- Check `node` and `npm`version

  ```bash

  node -v # Should print "v20.18.1".
  npm -v # Should print "10.8.2".

  ```

## Setup firebase app - very important !!

This section will require developer to login to a Google Account

- Go to https://firebase.google.com and login with your Google Account

- Navigate to Firebase console https://console.firebase.google.com

- Click on `Create a project`, then follow the steps to create a new project.

- Once you created the new project, go to your project page and click on `Add app`, then choose the button with `</>` symbol. This will add a web app manager to your project

- Follow the steps to add web app to your project

- Go back to your project page. On the left-hand side bar, there should be a cog icon next to `Project Overview` button. Click on the cog icon and choose `Project settings`

- Then, in the `General` tab of `Project settings`, scroll down and find `firebaseConfig` (you can use cmd+F to search for `firebaseConfig`)

  The `firebaseConfig` object should look like this

  ```typescript
  const firebaseConfig = {
    apiKey: "APIKey",
    authDomain: "new-app.firebaseapp.com",
    projectId: "project-id",
    storageBucket: "new-app.firebasestorage.app",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:123456789abcdef",
  };
  ```

- Copy the whole `firebaseConfig` and replace the existing `firebaseConfig` object in `./src/firebase.ts`

- Save the file

## Run application

- Open a terminal, and navigate to the root of this repository, run

  ```bash

  npm install

  ```

  This should create a folder called `node_modules`, where all the dependency libraries for the app is stored

- Run

  ```bash

  npm run dev

  ```

  This should boot up the development server. Your terminal should display something like this

  ```
    VITE v6.0.5  ready in 126 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
  ```

- Go to a web browser (Chrome) and then navigate to http://localhost:5173/. You should be able to see the web app's authentication page. You can create an account to log in to your web application.

# Documentation site

- Once the application development server is running, navigate to http://localhost:5173/docs to access the documentation site and playground
